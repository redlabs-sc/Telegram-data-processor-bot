package bot

import (
	"context"
	"database/sql"
	"fmt"
	"strings"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
	"telegram-archive-bot/monitoring"
	"telegram-archive-bot/pipeline"
	"telegram-archive-bot/storage"
	"telegram-archive-bot/utils"
	"telegram-archive-bot/workers"
)

type TelegramBot struct {
	bot      *tgbotapi.BotAPI
	config   *utils.Config
	logger   *utils.Logger
	handlers *Handlers
	ctx      context.Context
	cancel   context.CancelFunc
}

func NewTelegramBot(config *utils.Config, logger *utils.Logger, db *sql.DB) (*TelegramBot, error) {
	// Use custom Bot API client that supports local server for large files
	botAPIClient, err := utils.NewBotAPIClient(config, logger)
	if err != nil {
		return nil, fmt.Errorf("failed to create bot API client: %w", err)
	}
	
	bot := botAPIClient.BotAPI

	ctx, cancel := context.WithCancel(context.Background())

	tb := &TelegramBot{
		bot:    bot,
		config: config,
		logger: logger,
		ctx:    ctx,
		cancel: cancel,
	}

	tb.handlers = NewHandlers(tb, config, logger, db)

	logger.WithField("bot_username", bot.Self.UserName).Info("Telegram bot initialized successfully")

	return tb, nil
}

func (tb *TelegramBot) SetTaskStore(taskStore *storage.TaskStore) {
	tb.handlers.SetTaskStore(taskStore)
}

func (tb *TelegramBot) SetDownloadWorker(downloadWorker *workers.DownloadWorker) {
	tb.handlers.SetDownloadWorker(downloadWorker)
}

func (tb *TelegramBot) SetHealthMonitor(healthMonitor *monitoring.HealthMonitor) {
	tb.handlers.SetHealthMonitor(healthMonitor)
}

func (tb *TelegramBot) SetExtractionWorker(extractionWorker *workers.ExtractionWorker) {
	tb.handlers.SetExtractionWorker(extractionWorker)
}

func (tb *TelegramBot) SetConversionWorker(conversionWorker *workers.ConversionWorker) {
	tb.handlers.SetConversionWorker(conversionWorker)
}

func (tb *TelegramBot) SetPipelineCoordinator(pipelineCoordinator *pipeline.PipelineCoordinator) {
	tb.handlers.SetPipelineCoordinator(pipelineCoordinator)
}

func (tb *TelegramBot) GetBotAPI() *tgbotapi.BotAPI {
	return tb.bot
}

func (tb *TelegramBot) Start() error {
	tb.logger.Info("Starting Telegram bot...")

	u := tgbotapi.NewUpdate(0)
	u.Timeout = 60

	updates := tb.bot.GetUpdatesChan(u)

	for {
		select {
		case <-tb.ctx.Done():
			tb.logger.Info("Bot context cancelled, stopping...")
			return nil

		case update := <-updates:
			go tb.handleUpdate(update)
		}
	}
}

func (tb *TelegramBot) Stop() {
	tb.logger.Info("Stopping Telegram bot...")
	
	// Shutdown authentication middleware (including rate limiter)
	if tb.handlers != nil && tb.handlers.auth != nil {
		tb.handlers.auth.Shutdown()
	}
	
	tb.cancel()
	tb.bot.StopReceivingUpdates()
}

func (tb *TelegramBot) handleUpdate(update tgbotapi.Update) {
	defer func() {
		if r := recover(); r != nil {
			tb.logger.WithField("panic", r).Error("Panic in update handler")
		}
	}()

	if update.Message != nil {
		tb.handleMessage(update.Message)
	} else if update.CallbackQuery != nil {
		tb.handleCallbackQuery(update.CallbackQuery)
	}
}

func (tb *TelegramBot) handleMessage(message *tgbotapi.Message) {
	userID := message.From.ID

	if !tb.config.IsAdmin(userID) {
		tb.logger.WithUserID(userID).Warn("Unauthorized access attempt")
		tb.SendMessage(message.Chat.ID, "❌ Unauthorized access. This bot is restricted to authorized administrators only.")
		return
	}

	tb.logger.WithUserID(userID).WithField("message", message.Text).Info("Received message from admin")

	if message.IsCommand() {
		tb.handlers.HandleCommand(message)
	} else if message.Document != nil {
		tb.handlers.HandleDocument(message)
	} else {
		tb.SendMessage(message.Chat.ID, "Please send a command or a file for processing. Use /commands to see available commands.")
	}
}

func (tb *TelegramBot) handleCallbackQuery(callback *tgbotapi.CallbackQuery) {
	userID := callback.From.ID

	if !tb.config.IsAdmin(userID) {
		tb.logger.WithUserID(userID).Warn("Unauthorized callback attempt")
		return
	}

	tb.handlers.HandleCallback(callback)
}

func (tb *TelegramBot) SendMessage(chatID int64, text string) error {
	return tb.SendMessageWithOptions(chatID, text, nil)
}

func (tb *TelegramBot) SendMessageWithOptions(chatID int64, text string, options *MessageOptions) error {
	msg := tgbotapi.NewMessage(chatID, text)
	
	if options != nil {
		if options.ParseMode != "" {
			msg.ParseMode = options.ParseMode
		}
		if options.ReplyMarkup != nil {
			msg.ReplyMarkup = options.ReplyMarkup
		}
		if options.DisablePreview {
			msg.DisableWebPagePreview = true
		}
	}

	_, err := tb.bot.Send(msg)
	if err != nil {
		// If markdown parsing failed, retry without markdown
		if options != nil && options.ParseMode != "" && 
		   (strings.Contains(err.Error(), "can't parse entities") || 
		    strings.Contains(err.Error(), "Bad Request")) {
			
			tb.logger.WithField("chat_id", chatID).
				WithError(err).
				Warn("Markdown parsing failed, retrying with plain text")
			
			// Retry without parse mode (plain text)
			plainMsg := tgbotapi.NewMessage(chatID, text)
			if options.ReplyMarkup != nil {
				plainMsg.ReplyMarkup = options.ReplyMarkup
			}
			if options.DisablePreview {
				plainMsg.DisableWebPagePreview = true
			}
			
			_, retryErr := tb.bot.Send(plainMsg)
			if retryErr != nil {
				tb.logger.WithField("chat_id", chatID).WithError(retryErr).Error("Failed to send message even without markdown")
				return fmt.Errorf("failed to send message: %w", retryErr)
			}
			
			return nil // Successfully sent as plain text
		}
		
		tb.logger.WithField("chat_id", chatID).WithError(err).Error("Failed to send message")
		return fmt.Errorf("failed to send message: %w", err)
	}

	return nil
}

// EscapeMarkdown escapes special Markdown characters to prevent parsing errors
func (tb *TelegramBot) EscapeMarkdown(text string) string {
	// Characters that need escaping in Telegram Markdown: *_`[]()~>#+-=|{}.!
	escapeChars := []string{
		"*", "\\_", "`", "[", "]", "(", ")", "~", ">", "#", "+", "-", "=", "|", "{", "}", ".", "!",
	}
	
	result := text
	for _, char := range escapeChars {
		result = strings.ReplaceAll(result, char, "\\"+char)
	}
	
	return result
}

func (tb *TelegramBot) EditMessage(chatID int64, messageID int, text string, options *MessageOptions) error {
	msg := tgbotapi.NewEditMessageText(chatID, messageID, text)
	
	if options != nil {
		if options.ParseMode != "" {
			msg.ParseMode = options.ParseMode
		}
		if options.ReplyMarkup != nil {
			if markup, ok := options.ReplyMarkup.(*tgbotapi.InlineKeyboardMarkup); ok {
				msg.ReplyMarkup = markup
			}
		}
	}

	_, err := tb.bot.Send(msg)
	if err != nil {
		tb.logger.WithField("chat_id", chatID).WithField("message_id", messageID).WithError(err).Error("Failed to edit message")
		return fmt.Errorf("failed to edit message: %w", err)
	}

	return nil
}

func (tb *TelegramBot) AnswerCallback(callbackID string, text string) error {
	callback := tgbotapi.NewCallback(callbackID, text)
	
	_, err := tb.bot.Request(callback)
	if err != nil {
		tb.logger.WithField("callback_id", callbackID).WithError(err).Error("Failed to answer callback")
		return fmt.Errorf("failed to answer callback: %w", err)
	}

	return nil
}

type MessageOptions struct {
	ParseMode      string
	ReplyMarkup    interface{}
	DisablePreview bool
}