package bot

import (
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"telegram-archive-bot/utils"
)

type RateLimiter struct {
	logger   *utils.Logger
	mutex    sync.Mutex
	lastSent map[int64]time.Time
	minDelay time.Duration
}

func NewRateLimiter(logger *utils.Logger) *RateLimiter {
	return &RateLimiter{
		logger:   logger,
		lastSent: make(map[int64]time.Time),
		minDelay: time.Second, // Minimum 1 second between messages to same chat
	}
}

func (rl *RateLimiter) CanSend(chatID int64) bool {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	now := time.Now()
	if lastTime, exists := rl.lastSent[chatID]; exists {
		if now.Sub(lastTime) < rl.minDelay {
			return false
		}
	}

	rl.lastSent[chatID] = now
	return true
}

func (rl *RateLimiter) WaitForNext(chatID int64) time.Duration {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	if lastTime, exists := rl.lastSent[chatID]; exists {
		elapsed := time.Since(lastTime)
		if elapsed < rl.minDelay {
			return rl.minDelay - elapsed
		}
	}
	return 0
}

func (tb *TelegramBot) SendMessageWithRetry(chatID int64, text string, options *MessageOptions) error {
	return tb.sendWithRetry(func() error {
		return tb.SendMessageWithOptions(chatID, text, options)
	}, chatID, "send_message")
}

func (tb *TelegramBot) EditMessageWithRetry(chatID int64, messageID int, text string, options *MessageOptions) error {
	return tb.sendWithRetry(func() error {
		return tb.EditMessage(chatID, messageID, text, options)
	}, chatID, "edit_message")
}

func (tb *TelegramBot) sendWithRetry(operation func() error, chatID int64, operationType string) error {
	maxRetries := 3
	baseDelay := time.Second

	for attempt := 0; attempt < maxRetries; attempt++ {
		err := operation()
		if err == nil {
			return nil
		}

		if floodWait := tb.parseFloodWaitError(err); floodWait > 0 {
			tb.logger.WithField("flood_wait_seconds", floodWait).
				WithField("chat_id", chatID).
				WithField("operation", operationType).
				Warn("FloodWait detected, waiting before retry")

			time.Sleep(time.Duration(floodWait) * time.Second)
			continue
		}

		if tb.isRetryableError(err) {
			delay := baseDelay * time.Duration(1<<attempt) // Exponential backoff
			tb.logger.WithField("attempt", attempt+1).
				WithField("delay_seconds", delay.Seconds()).
				WithField("error", err.Error()).
				WithField("operation", operationType).
				Warn("Retryable error, waiting before retry")

			time.Sleep(delay)
			continue
		}

		// Non-retryable error
		tb.logger.WithField("error", err.Error()).
			WithField("operation", operationType).
			Error("Non-retryable error in Telegram API call")
		return err
	}

	return fmt.Errorf("maximum retries exceeded for %s", operationType)
}

func (tb *TelegramBot) parseFloodWaitError(err error) int {
	if err == nil {
		return 0
	}

	errorText := err.Error()
	
	// Check for FloodWait error patterns
	patterns := []string{
		"Too Many Requests: retry after ",
		"FloodWait ",
		"flood_wait_",
	}

	for _, pattern := range patterns {
		if strings.Contains(errorText, pattern) {
			// Extract the wait time
			parts := strings.Split(errorText, pattern)
			if len(parts) > 1 {
				// Try to extract number from the next part
				waitStr := strings.Fields(parts[1])[0]
				if waitTime, err := strconv.Atoi(waitStr); err == nil {
					return waitTime
				}
			}
		}
	}

	return 0
}

func (tb *TelegramBot) isRetryableError(err error) bool {
	if err == nil {
		return false
	}

	errorText := strings.ToLower(err.Error())
	
	retryableErrors := []string{
		"internal server error",
		"bad gateway",
		"service temporarily unavailable",
		"gateway timeout",
		"network error",
		"timeout",
		"connection reset",
		"connection refused",
		"temporary failure",
	}

	for _, retryable := range retryableErrors {
		if strings.Contains(errorText, retryable) {
			return true
		}
	}

	return false
}

// Enhanced message sending with built-in rate limiting
func (tb *TelegramBot) SendMessageSafe(chatID int64, text string) error {
	return tb.SendMessageWithOptions(chatID, text, &MessageOptions{
		ParseMode: "Markdown",
	})
}

// Batch message sender for multiple updates
func (tb *TelegramBot) SendBatchMessages(messages []BatchMessage) []error {
	errors := make([]error, len(messages))
	
	for i, msg := range messages {
		err := tb.SendMessageWithRetry(msg.ChatID, msg.Text, msg.Options)
		if err != nil {
			errors[i] = err
			tb.logger.WithField("batch_index", i).
				WithField("chat_id", msg.ChatID).
				WithError(err).
				Error("Failed to send batch message")
		}
	}
	
	return errors
}

type BatchMessage struct {
	ChatID  int64
	Text    string
	Options *MessageOptions
}