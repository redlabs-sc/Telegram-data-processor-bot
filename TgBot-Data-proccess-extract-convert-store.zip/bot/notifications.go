package bot

import (
	"fmt"
	"time"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api/v5"
	"telegram-archive-bot/models"
	"telegram-archive-bot/utils"
)

type NotificationService struct {
	bot    *TelegramBot
	logger *utils.Logger
}

func NewNotificationService(bot *TelegramBot, logger *utils.Logger) *NotificationService {
	return &NotificationService{
		bot:    bot,
		logger: logger,
	}
}

func (ns *NotificationService) NotifyTaskCreated(chatID int64, task *models.Task) error {
	text := fmt.Sprintf(`📥 **File Received**

📁 **Name:** %s
📊 **Size:** %.2f MB
🔄 **Status:** %s PENDING
🆔 **Task ID:** %s
⏰ **Time:** %s

⏳ File has been queued for processing...`,
		task.FileName,
		float64(task.FileSize)/(1024*1024),
		ns.getStatusEmoji(task.Status),
		task.ID,
		task.CreatedAt.Format("15:04:05"))

	keyboard := ns.createTaskKeyboard(task.ID)
	options := &MessageOptions{
		ParseMode:   "Markdown",
		ReplyMarkup: keyboard,
	}

	return ns.bot.SendMessageWithRetry(chatID, text, options)
}

func (ns *NotificationService) NotifyTaskProgress(chatID int64, task *models.Task, messageID int) error {
	text := fmt.Sprintf(`🔄 **Processing Update**

📁 **Name:** %s
🔄 **Status:** %s %s
🆔 **Task ID:** %s
⏰ **Updated:** %s

⏳ Processing in progress...`,
		task.FileName,
		ns.getStatusEmoji(task.Status),
		string(task.Status),
		task.ID,
		task.UpdatedAt.Format("15:04:05"))

	keyboard := ns.createTaskKeyboard(task.ID)
	options := &MessageOptions{
		ParseMode:   "Markdown",
		ReplyMarkup: keyboard,
	}

	return ns.bot.EditMessageWithRetry(chatID, messageID, text, options)
}

func (ns *NotificationService) NotifyTaskCompleted(chatID int64, task *models.Task, messageID int) error {
	text := fmt.Sprintf(`✅ **Processing Complete**

📁 **Name:** %s
🔄 **Status:** %s %s
🆔 **Task ID:** %s
⏰ **Completed:** %s
⏱️ **Duration:** %s

🎉 File processed successfully!`,
		task.FileName,
		ns.getStatusEmoji(task.Status),
		string(task.Status),
		task.ID,
		task.CompletedAt.Format("15:04:05"),
		task.CompletedAt.Sub(task.CreatedAt).Round(time.Second))

	keyboard := ns.createCompletedKeyboard(task.ID)
	options := &MessageOptions{
		ParseMode:   "Markdown",
		ReplyMarkup: keyboard,
	}

	return ns.bot.EditMessageWithRetry(chatID, messageID, text, options)
}

func (ns *NotificationService) NotifyTaskFailed(chatID int64, task *models.Task, messageID int) error {
	text := fmt.Sprintf(`❌ **Processing Failed**

📁 **Name:** %s
🔄 **Status:** %s %s
🆔 **Task ID:** %s
⏰ **Failed:** %s
❗ **Error:** %s

🔧 Check logs for more details.`,
		task.FileName,
		ns.getStatusEmoji(task.Status),
		string(task.Status),
		task.ID,
		task.CompletedAt.Format("15:04:05"),
		task.ErrorMessage)

	keyboard := ns.createFailedKeyboard(task.ID)
	options := &MessageOptions{
		ParseMode:   "Markdown",
		ReplyMarkup: keyboard,
	}

	return ns.bot.EditMessageWithRetry(chatID, messageID, text, options)
}

func (ns *NotificationService) NotifySystemStatus(chatID int64, status string, details string) error {
	text := fmt.Sprintf(`🤖 **System Notification**

🔄 **Status:** %s
📋 **Details:** %s
⏰ **Time:** %s`,
		status,
		details,
		time.Now().Format("15:04:05"))

	options := &MessageOptions{
		ParseMode: "Markdown",
	}

	return ns.bot.SendMessageWithRetry(chatID, text, options)
}

func (ns *NotificationService) NotifyQueueStatus(chatID int64, pending, processing, completed int) error {
	text := fmt.Sprintf(`📊 **Queue Status Update**

⏳ **Pending:** %d files
🔄 **Processing:** %d files
✅ **Completed:** %d files
⏰ **Updated:** %s`,
		pending,
		processing,
		completed,
		time.Now().Format("15:04:05"))

	keyboard := ns.createQueueKeyboard()
	options := &MessageOptions{
		ParseMode:   "Markdown",
		ReplyMarkup: keyboard,
	}

	return ns.bot.SendMessageWithRetry(chatID, text, options)
}

func (ns *NotificationService) getStatusEmoji(status models.TaskStatus) string {
	switch status {
	case models.TaskStatusPending:
		return "⏳"
	case models.TaskStatusDownloaded:
		return "📥"
	case models.TaskStatusCompleted:
		return "✅"
	case models.TaskStatusFailed:
		return "❌"
	default:
		return "❓"
	}
}

func (ns *NotificationService) createTaskKeyboard(taskID string) *tgbotapi.InlineKeyboardMarkup {
	keyboard := tgbotapi.NewInlineKeyboardMarkup(
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("🔄 Refresh", fmt.Sprintf("refresh_%s", taskID)),
			tgbotapi.NewInlineKeyboardButtonData("⏹️ Cancel", fmt.Sprintf("cancel_%s", taskID)),
		),
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("📊 Queue Status", "queue_status"),
		),
	)
	return &keyboard
}

func (ns *NotificationService) createCompletedKeyboard(taskID string) *tgbotapi.InlineKeyboardMarkup {
	keyboard := tgbotapi.NewInlineKeyboardMarkup(
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("📋 View Details", fmt.Sprintf("details_%s", taskID)),
			tgbotapi.NewInlineKeyboardButtonData("🗑️ Archive", fmt.Sprintf("archive_%s", taskID)),
		),
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("📊 Stats", "stats"),
		),
	)
	return &keyboard
}

func (ns *NotificationService) createFailedKeyboard(taskID string) *tgbotapi.InlineKeyboardMarkup {
	keyboard := tgbotapi.NewInlineKeyboardMarkup(
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("🔄 Retry", fmt.Sprintf("retry_%s", taskID)),
			tgbotapi.NewInlineKeyboardButtonData("📋 View Error", fmt.Sprintf("error_%s", taskID)),
		),
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("🗑️ Delete", fmt.Sprintf("delete_%s", taskID)),
		),
	)
	return &keyboard
}

func (ns *NotificationService) createQueueKeyboard() *tgbotapi.InlineKeyboardMarkup {
	keyboard := tgbotapi.NewInlineKeyboardMarkup(
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("🔄 Refresh", "refresh_queue"),
			tgbotapi.NewInlineKeyboardButtonData("⏹️ Stop All", "stop_all"),
		),
		tgbotapi.NewInlineKeyboardRow(
			tgbotapi.NewInlineKeyboardButtonData("🧹 Cleanup", "cleanup"),
			tgbotapi.NewInlineKeyboardButtonData("📊 Stats", "stats"),
		),
	)
	return &keyboard
}

// Enhanced formatting utilities
func (ns *NotificationService) FormatFileSize(bytes int64) string {
	const unit = 1024
	if bytes < unit {
		return fmt.Sprintf("%d B", bytes)
	}
	div, exp := int64(unit), 0
	for n := bytes / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(bytes)/float64(div), "KMGTPE"[exp])
}

func (ns *NotificationService) FormatDuration(duration time.Duration) string {
	if duration < time.Minute {
		return fmt.Sprintf("%d seconds", int(duration.Seconds()))
	}
	if duration < time.Hour {
		return fmt.Sprintf("%d minutes", int(duration.Minutes()))
	}
	return fmt.Sprintf("%.1f hours", duration.Hours())
}