package bot

import (
	"database/sql"
	"time"

	"telegram-archive-bot/storage"
	"telegram-archive-bot/utils"
)

type AuthMiddleware struct {
	config      *utils.Config
	logger      *utils.Logger
	rateLimiter *utils.RateLimiter
	auditLogger *storage.AdminAuditLogger
}

func NewAuthMiddleware(config *utils.Config, logger *utils.Logger, db *sql.DB) *AuthMiddleware {
	// Initialize rate limiter with default configuration
	rateLimiter := utils.NewRateLimiter(utils.DefaultRateLimitConfig(), logger)
	
	// Initialize admin audit logger
	auditLogger := storage.NewAdminAuditLogger(db, logger)
	
	return &AuthMiddleware{
		config:      config,
		logger:      logger,
		rateLimiter: rateLimiter,
		auditLogger: auditLogger,
	}
}

func (am *AuthMiddleware) IsAuthorized(userID int64) bool {
	authorized := am.config.IsAdmin(userID)
	
	if !authorized {
		am.logger.WithUserID(userID).Warn("Unauthorized access attempt")
	} else {
		am.logger.WithUserID(userID).Debug("Admin access authorized")
	}
	
	return authorized
}

func (am *AuthMiddleware) LogUnauthorizedAttempt(userID int64, username, action string) {
	am.logger.WithField("user_id", userID).
		WithField("username", username).
		WithField("action", action).
		Warn("Unauthorized action attempted")
	
	// Log to audit trail
	am.auditLogger.LogUnauthorizedAttempt(userID, username, action, "")
}

func (am *AuthMiddleware) LogAuthorizedAction(userID int64, username, action string) {
	am.logger.WithField("user_id", userID).
		WithField("username", username).
		WithField("action", action).
		Info("Authorized admin action")
}

// CheckCommandRateLimit checks if a command is allowed under rate limiting
func (am *AuthMiddleware) CheckCommandRateLimit(userID int64, username, command string) (bool, error) {
	return am.rateLimiter.AllowCommand(userID, username, command)
}

// CheckFileUploadRateLimit checks if a file upload is allowed under rate limiting
func (am *AuthMiddleware) CheckFileUploadRateLimit(userID int64, username, fileName string, fileSize int64) (bool, error) {
	return am.rateLimiter.AllowFileUpload(userID, username, fileName, fileSize)
}

// GetRateLimiter returns the rate limiter instance
func (am *AuthMiddleware) GetRateLimiter() *utils.RateLimiter {
	return am.rateLimiter
}

// IsUserBlocked checks if a user is currently rate limited
func (am *AuthMiddleware) IsUserBlocked(userID int64) (bool, string) {
	blocked, until := am.rateLimiter.IsUserBlocked(userID)
	if blocked {
		return true, until.Format("2006-01-02 15:04:05")
	}
	return false, ""
}

// ResetUserRateLimits resets rate limits for a specific user (admin function)
func (am *AuthMiddleware) ResetUserRateLimits(userID int64) {
	am.rateLimiter.ResetUserLimits(userID)
	am.logger.WithField("user_id", userID).Info("Rate limits reset for user")
}

// LogCommand logs a command execution to the audit trail
func (am *AuthMiddleware) LogCommand(userID int64, username, command, args string, startTime time.Time, err error) {
	duration := time.Since(startTime)
	result := "SUCCESS"
	if err != nil {
		result = "FAILED"
	}
	
	am.auditLogger.LogCommand(userID, username, command, args, result, duration, err)
}

// LogFileOperation logs file operations to the audit trail
func (am *AuthMiddleware) LogFileOperation(userID int64, username string, action storage.AdminAuditAction, fileName string, fileSize int64, details map[string]interface{}, result string, err error) {
	am.auditLogger.LogFileOperation(userID, username, action, fileName, fileSize, details, result, err)
}

// LogSystemAction logs system-level actions to the audit trail
func (am *AuthMiddleware) LogSystemAction(userID int64, username string, action storage.AdminAuditAction, resource string, details map[string]interface{}, result string, err error) {
	am.auditLogger.LogSystemAction(userID, username, action, resource, details, result, err)
}

// LogSecurityEvent logs security-related events to the audit trail
func (am *AuthMiddleware) LogSecurityEvent(userID int64, username string, action storage.AdminAuditAction, resource string, details map[string]interface{}, severity string) {
	am.auditLogger.LogSecurityEvent(userID, username, action, resource, details, severity)
}

// GetAuditLogger returns the admin audit logger instance
func (am *AuthMiddleware) GetAuditLogger() *storage.AdminAuditLogger {
	return am.auditLogger
}

// Shutdown gracefully shuts down the auth middleware
func (am *AuthMiddleware) Shutdown() {
	if am.rateLimiter != nil {
		am.rateLimiter.Shutdown()
	}
}