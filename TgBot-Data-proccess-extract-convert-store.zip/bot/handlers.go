package bot

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/go-telegram-bot-api/telegram-bot-api/v5"

	"telegram-archive-bot/app/extraction"
	"telegram-archive-bot/app/extraction/extract"
	"telegram-archive-bot/models"
	"telegram-archive-bot/monitoring"
	"telegram-archive-bot/pipeline"
	"telegram-archive-bot/storage"
	"telegram-archive-bot/utils"
	"telegram-archive-bot/workers"
)

type Handlers struct {
	bot                 *TelegramBot
	config              *utils.Config
	logger              *utils.Logger
	auth                *AuthMiddleware
	taskStore           *storage.TaskStore
	downloadWorker      *workers.DownloadWorker
	extractionWorker    *workers.ExtractionWorker
	conversionWorker    *workers.ConversionWorker
	pipelineCoordinator *pipeline.PipelineCoordinator
	healthMonitor       *monitoring.HealthMonitor
	deadLetterQueue     *storage.DeadLetterQueue
	deadLetterManager   *storage.DeadLetterManager
	circuitBreaker      *utils.SubprocessCircuitBreaker
	startTime           time.Time
}

func NewHandlers(bot *TelegramBot, config *utils.Config, logger *utils.Logger, db *sql.DB) *Handlers {
	return &Handlers{
		bot:       bot,
		config:    config,
		logger:    logger,
		auth:      NewAuthMiddleware(config, logger, db),
		startTime: time.Now(),
	}
}

func (h *Handlers) SetTaskStore(taskStore *storage.TaskStore) {
	h.taskStore = taskStore
}

func (h *Handlers) SetDownloadWorker(downloadWorker *workers.DownloadWorker) {
	h.downloadWorker = downloadWorker
}

func (h *Handlers) SetHealthMonitor(healthMonitor *monitoring.HealthMonitor) {
	h.healthMonitor = healthMonitor
}

func (h *Handlers) SetDeadLetterQueue(deadLetterQueue *storage.DeadLetterQueue) {
	h.deadLetterQueue = deadLetterQueue
}

func (h *Handlers) SetDeadLetterManager(deadLetterManager *storage.DeadLetterManager) {
	h.deadLetterManager = deadLetterManager
}

func (h *Handlers) SetCircuitBreaker(circuitBreaker *utils.SubprocessCircuitBreaker) {
	h.circuitBreaker = circuitBreaker
}

func (h *Handlers) SetExtractionWorker(extractionWorker *workers.ExtractionWorker) {
	h.extractionWorker = extractionWorker
}

func (h *Handlers) SetConversionWorker(conversionWorker *workers.ConversionWorker) {
	h.conversionWorker = conversionWorker
}

func (h *Handlers) SetPipelineCoordinator(pipelineCoordinator *pipeline.PipelineCoordinator) {
	h.pipelineCoordinator = pipelineCoordinator
}

func (h *Handlers) HandleCommand(message *tgbotapi.Message) {
	userID := message.From.ID
	username := message.From.UserName
	command := message.Command()
	args := message.CommandArguments()
	startTime := time.Now()

	if !h.auth.IsAuthorized(userID) {
		h.auth.LogUnauthorizedAttempt(userID, username, fmt.Sprintf("command: %s", command))
		h.bot.SendMessage(message.Chat.ID, "❌ Unauthorized access. This bot is restricted to authorized administrators only.")
		return
	}

	// Check rate limits for commands
	allowed, err := h.auth.CheckCommandRateLimit(userID, username, command)
	if !allowed {
		h.logger.WithField("user_id", userID).
			WithField("username", username).
			WithField("command", command).
			WithError(err).
			Warn("Command blocked due to rate limiting")
		
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("⏰ Rate limit exceeded: %v\nPlease wait before sending more commands.", err))
		return
	}

	h.auth.LogAuthorizedAction(userID, username, fmt.Sprintf("command: %s", command))

	// Defer audit logging to capture execution time and any errors
	defer func() {
		if r := recover(); r != nil {
			// Log panic as failed command
			h.auth.LogCommand(userID, username, command, args, startTime, fmt.Errorf("panic: %v", r))
			panic(r) // Re-panic to maintain original behavior
		} else {
			// Log successful command execution
			h.auth.LogCommand(userID, username, command, args, startTime, nil)
		}
	}()

	switch command {
	case "start":
		h.handleStart(message)
	case "help":
		h.handleHelp(message)
	case "commands":
		h.handleCommands(message)
	case "stats":
		h.handleStats(message)
	case "health":
		h.handleHealth(message)
	case "metrics":
		h.handleMetrics(message)
	case "system":
		h.handleSystem(message)
	case "alerts":
		h.handleAlerts(message)
	case "alertrules":
		h.handleAlertRules(message)
	case "diagnostics":
		h.handleDiagnostics(message)
	case "extract":
		h.handleExtract(message)
	case "convert":
		h.handleConvert(message, args)
	case "full":
		h.handleFull(message)
	case "process":
		h.handleProcess(message)
	case "store":
		h.handleStore(message)
	case "queue":
		h.handleQueue(message)
	case "stop":
		h.handleStop(message)
	case "cleanup":
		h.handleCleanup(message)
	case "exit":
		h.handleExit(message)
	case "deadletter":
		h.handleDeadLetter(message)
	case "dlstats":
		h.handleDeadLetterStats(message)
	case "dlretry":
		h.handleDeadLetterRetry(message, parseArgs(args))
	case "dlbulkretry":
		h.handleDeadLetterBulkRetry(message, parseArgs(args))
	case "dlcleanup":
		h.handleDeadLetterCleanup(message, parseArgs(args))
	case "cbstatus":
		h.handleCircuitBreakerStatus(message)
	case "cbreset":
		h.handleCircuitBreakerReset(message, parseArgs(args))
	case "cbopen":
		h.handleCircuitBreakerOpen(message, parseArgs(args))
	case "degradation":
		h.handleGracefulDegradation(message)
	case "dephealth":
		h.handleDependencyHealth(message)
	case "queuestatus":
		h.handleQueueStatus(message)
	case "security":
		h.handleSecurity(message)
	case "secstats":
		h.handleSecurityStats(message, parseArgs(args))
	case "quarantine":
		h.handleQuarantine(message)
	case "signatures":
		h.handleSignatures(message)
	case "tempstats":
		h.handleTempStats(message)
	case "ratelimit":
		h.handleRateLimit(message, parseArgs(args))
	case "audit":
		h.handleAudit(message, parseArgs(args))
	case "move":
		h.handleMove(message)
	default:
		h.handleUnknownCommand(message, command)
	}
}

func (h *Handlers) HandleDocument(message *tgbotapi.Message) {
	userID := message.From.ID
	username := message.From.UserName

	if !h.auth.IsAuthorized(userID) {
		h.auth.LogUnauthorizedAttempt(userID, username, "file upload")
		h.bot.SendMessage(message.Chat.ID, "❌ Unauthorized access. This bot is restricted to authorized administrators only.")
		return
	}

	doc := message.Document
	
	// Check for abuse protection (users can still be blocked for abusive behavior)
	allowed, err := h.auth.CheckFileUploadRateLimit(userID, username, doc.FileName, int64(doc.FileSize))
	if !allowed {
		h.logger.WithField("user_id", userID).
			WithField("username", username).
			WithField("file_name", doc.FileName).
			WithField("file_size", doc.FileSize).
			WithError(err).
			Warn("File upload blocked due to user being temporarily blocked")
		
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("🚫 Upload blocked: %v", err))
		return
	}

	h.auth.LogAuthorizedAction(userID, username, "file upload")

	// Log file upload to audit trail
	fileDetails := map[string]interface{}{
		"mime_type":      doc.MimeType,
		"telegram_file_id": doc.FileID,
	}
	h.auth.LogFileOperation(userID, username, storage.AdminActionFileUpload, doc.FileName, int64(doc.FileSize), fileDetails, "ACCEPTED", nil)

	h.logger.WithField("file_name", doc.FileName).
		WithField("file_size", doc.FileSize).
		WithField("mime_type", doc.MimeType).
		Info("Received file from admin")

	// Validate file size
	if int64(doc.FileSize) > h.config.MaxFileSizeBytes() {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ File too large. Maximum size allowed: %dMB", h.config.MaxFileSizeMB))
		return
	}

	// Validate file type
	supportedTypes := []string{".zip", ".rar", ".txt"}
	fileName := strings.ToLower(doc.FileName)
	fileType := ""
	supported := false
	for _, ext := range supportedTypes {
		if strings.HasSuffix(fileName, ext) {
			supported = true
			fileType = ext[1:] // Remove dot
			break
		}
	}

	if !supported {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Unsupported file type. Supported types: %s", strings.Join(supportedTypes, ", ")))
		return
	}

	// Create task in database with PENDING status
	task := &models.Task{
		FileName:   doc.FileName,
		FileSize:   int64(doc.FileSize),
		FileType:   fileType,
		Status:     models.TaskStatusPending,
		ChatID:     message.Chat.ID,
		UserID:     userID,
		TelegramFileID: doc.FileID,
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}

	// Save task to database
	if err := h.taskStore.Create(task); err != nil {
		h.logger.WithError(err).
			WithField("file_name", doc.FileName).
			Error("Failed to create task in database")
		h.bot.SendMessage(message.Chat.ID, "❌ Failed to create download task. Please try again.")
		return
	}

	h.logger.WithField("task_id", task.ID).
		WithField("file_name", doc.FileName).
		Info("Task created successfully")

	// Send initial confirmation
	confirmText := fmt.Sprintf(`📥 **File Received & Queued**

📄 **Name:** %s
📊 **Size:** %.2fMB
🔧 **Type:** %s
🆔 **Task ID:** %s

⏳ **Status:** Queued for download
🚀 **Concurrent Downloads:** Up to 3 files processed simultaneously
📋 **Position:** Added to download queue

Your file will be downloaded automatically when a worker becomes available.`, 
		doc.FileName, 
		float64(doc.FileSize)/(1024*1024),
		strings.ToUpper(fileType),
		task.ID)

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, confirmText, options)

	// Record file received metric
	if h.healthMonitor != nil && h.healthMonitor.GetMetrics() != nil {
		h.healthMonitor.GetMetrics().IncrementCounter("files_received")
	}

	// Start automatic download process
	if err := h.startFileDownload(task); err != nil {
		h.logger.WithError(err).
			WithField("task_id", task.ID).
			Error("Failed to start download process")
		
		// Update task status to failed
		h.taskStore.UpdateStatus(task.ID, models.TaskStatusFailed, err.Error())
		
		// Notify user of failure
		failureText := fmt.Sprintf(`❌ **Download Failed**

🆔 **Task ID:** %s
📄 **File:** %s
⚠️ **Error:** %s

Please try uploading the file again.`, task.ID, doc.FileName, err.Error())

		h.bot.SendMessageWithOptions(message.Chat.ID, failureText, options)
		return
	}
}

func (h *Handlers) HandleCallback(callback *tgbotapi.CallbackQuery) {
	userID := callback.From.ID
	username := callback.From.UserName

	if !h.auth.IsAuthorized(userID) {
		h.auth.LogUnauthorizedAttempt(userID, username, "callback")
		return
	}

	h.auth.LogAuthorizedAction(userID, username, fmt.Sprintf("callback: %s", callback.Data))

	// TODO: Implement callback handling for inline buttons
	h.bot.AnswerCallback(callback.ID, "Feature coming soon!")
}

func (h *Handlers) handleStart(message *tgbotapi.Message) {
	text := `🤖 **Telegram Archive Bot**

Welcome, admin! This bot processes ZIP, RAR, and TXT files automatically.

**Available Commands:**
/commands - Show all commands and system status
/stats - Show bot statistics and uptime
/health - Show detailed system health check
/metrics - Show performance metrics and throughput
/system - Show detailed system resource usage
/queue - Show processing queue and task status
/process - Automatically run extraction and conversion
/extract - Manually trigger extraction process
/convert - Manually trigger conversion process
/cleanup - Clean temporary and error files
/stop - Stop all operations
/exit - Safe shutdown

Send a file to start automatic processing!`

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleHelp(message *tgbotapi.Message) {
	h.handleStart(message)
}

func (h *Handlers) handleCommands(message *tgbotapi.Message) {
	// TODO: Implement system diagnostics
	text := `🔧 **Available Commands:**

📊 **Status & Monitoring:**
/stats - Bot uptime, file counts, disk usage
/health - Detailed system health check
/metrics - Performance metrics and throughput
/system - Detailed system resource usage
/queue - Processing queue and task status

🚨 **Alerting & Monitoring:**
/alerts - View active alerts and statistics
/alertrules - View alert rules configuration
/diagnostics - Run and view self-diagnostic checks

⚙️ **Processing Controls:**
/process - Automatically run extraction then conversion (recommended)
/extract - Trigger extraction from files/all → files/pass
/convert - Trigger conversion from files/pass → output
/store - Process text files through merger, filter, and database pipeline
/stop - Force stop all operations and clear queues

🧹 **Maintenance:**
/cleanup - Delete files in errors/ and nopass/ directories
/move - Manual move files from Local Bot API (files auto-move by default)
/exit - Safe shutdown with task persistence

💀 **Dead Letter Queue:**
/deadletter - View dead letter queue status and recent entries
/dlstats - Detailed dead letter queue statistics
/dlretry <id> - Retry specific task from dead letter queue
/dlbulkretry <reason> [max] - Bulk retry tasks by reason (max: optional limit)
/dlcleanup <days> - Remove old non-retryable entries older than X days

🔌 **Circuit Breakers:**
/cbstatus - View circuit breaker status for external processes
/cbreset [process] - Reset circuit breaker (all or specific process)
/cbopen [process] - Manually open circuit breaker

🛡️ **Graceful Degradation:**
/degradation - System graceful degradation status
/dephealth - Detailed dependency health report
/queuestatus - View queued operations status

🔒 **Security & Validation:**
/security - Security system status and recent events
/secstats [hours] - Detailed security statistics (default: 24h)
/quarantine - View quarantined files status
/signatures - Enhanced file signature validation info
/tempstats - Secure temporary file management statistics
/ratelimit [users|status|reset] - Rate limiting system management
/audit [stats|recent|user|action|cleanup] - Admin action audit log system

🤖 **System Status:** ✅ All systems operational
📁 **Extract.go:** Available in app/extraction/
🔄 **Convert.go:** Available in app/extraction/
💾 **Database:** Connected and ready`

	options := &MessageOptions{
		ParseMode: "",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleStats(message *tgbotapi.Message) {
	uptime := time.Since(h.startTime).Round(time.Second)
	
	// Get memory stats
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	
	// Get disk usage for key directories
	extractionDir := "app/extraction/files"
	dataDir := "data"
	logsDir := "logs"
	tempDir := "temp"
	
	// Get task statistics
	taskStats, err := h.getTaskStatistics()
	var statsText string
	if err != nil {
		h.logger.WithError(err).Error("Failed to get task statistics")
		statsText = `📈 **Processing Stats:**
• Error retrieving task statistics`
	} else {
		statsText = fmt.Sprintf(`📈 **Processing Stats:**
• Total Tasks: %d
• Completed: %d  
• Failed: %d
• Downloaded (awaiting manual processing): %d
• Pending Downloads: %d`,
			taskStats.Total,
			taskStats.Completed,
			taskStats.Failed,
			taskStats.Downloaded,
			taskStats.Pending)
	}
	
	text := fmt.Sprintf(`📊 **Bot Statistics**

⏱️ **Uptime:** %s
🖥️ **Memory Usage:** %.2f MB
🐹 **Goroutines:** %d

📁 **Directory Status:**
• Extraction: %s
• Database: %s  
• Logs: %s
• Temp: %s

%s

🔄 **Last Updated:** %s`,
		uptime.String(),
		float64(m.Alloc)/1024/1024,
		runtime.NumGoroutine(),
		h.getDirStatus(extractionDir),
		h.getDirStatus(dataDir),
		h.getDirStatus(logsDir),
		h.getDirStatus(tempDir),
		statsText,
		time.Now().Format("15:04:05"))
	
	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleHealth(message *tgbotapi.Message) {
	if h.healthMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Health monitor not initialized")
		return
	}

	// Get the latest health check
	healthCheck := h.healthMonitor.GetLastHealthCheck()
	if healthCheck == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ No health check data available")
		return
	}

	// Build status emoji
	var statusEmoji string
	switch healthCheck.Status {
	case monitoring.HealthStatusHealthy:
		statusEmoji = "✅"
	case monitoring.HealthStatusDegraded:
		statusEmoji = "⚠️"
	case monitoring.HealthStatusUnhealthy:
		statusEmoji = "❌"
	default:
		statusEmoji = "❓"
	}

	// Format uptime
	uptime := healthCheck.Uptime.Round(time.Second)

	text := fmt.Sprintf(`🏥 **System Health Check**

%s **Overall Status:** %s
⏱️ **Uptime:** %s
🕒 **Last Check:** %s
🖥️ **Memory:** %.1fMB (%.1f%%)
🔧 **Goroutines:** %d

📊 **Component Health:**`,
		statusEmoji,
		string(healthCheck.Status),
		uptime.String(),
		healthCheck.Timestamp.Format("15:04:05"),
		healthCheck.SystemInfo.MemoryUsage,
		healthCheck.SystemInfo.MemoryPercent,
		healthCheck.SystemInfo.Goroutines)

	// Add component details
	for _, component := range healthCheck.Components {
		var compEmoji string
		switch component.Status {
		case monitoring.HealthStatusHealthy:
			compEmoji = "✅"
		case monitoring.HealthStatusDegraded:
			compEmoji = "⚠️"
		case monitoring.HealthStatusUnhealthy:
			compEmoji = "❌"
		default:
			compEmoji = "❓"
		}
		
		text += fmt.Sprintf("\n• %s **%s**: %s (%dms)",
			compEmoji,
			component.Name,
			component.Message,
			component.ResponseTimeMs)
	}

	text += fmt.Sprintf("\n\n🔄 **System Info:**\n• Start Time: %s\n• Monitoring: Active (30s intervals)",
		healthCheck.SystemInfo.StartTime.Format("2006-01-02 15:04:05"))

	options := &MessageOptions{
		ParseMode: "",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleMetrics(message *tgbotapi.Message) {
	if h.healthMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Health monitor not initialized")
		return
	}

	metrics := h.healthMonitor.GetMetrics()
	if metrics == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Performance metrics not available")
		return
	}

	// Get processing metrics
	processingMetrics := metrics.GetProcessingMetrics()
	queueMetrics := metrics.GetQueueMetrics()
	counters := metrics.GetCounters()
	timings := metrics.GetTimings()

	text := fmt.Sprintf(`📊 **Performance Metrics**

📈 **Processing Performance:**`)

	// Add processing stage metrics
	for stage, pm := range processingMetrics {
		var stageEmoji string
		switch stage {
		case "download":
			stageEmoji = "📥"
		case "extraction":
			stageEmoji = "🔧"
		case "conversion":
			stageEmoji = "⚙️"
		default:
			stageEmoji = "📊"
		}
		
		text += fmt.Sprintf(`
%s **%s Stage:**
• Processed: %d (%.1f%% success)
• Failed: %d
• Avg Time: %s
• Throughput: %.1f/hour
• Active Jobs: %d`,
			stageEmoji,
			strings.Title(stage),
			pm.TotalProcessed,
			pm.SuccessRate,
			pm.TotalFailed,
			pm.AvgProcessTime.Round(time.Millisecond).String(),
			pm.Throughput,
			pm.ActiveJobs)
	}

	text += fmt.Sprintf(`

📋 **Queue Metrics:**
• Pending: %d tasks
• Downloaded: %d tasks  
• Completed: %d tasks
• Failed: %d tasks
• Queue Depth: %d
• Total Tasks: %d`,
		queueMetrics.PendingTasks,
		queueMetrics.DownloadedTasks,
		queueMetrics.CompletedTasks,
		queueMetrics.FailedTasks,
		queueMetrics.QueueDepth,
		queueMetrics.TotalTasks)

	text += "\n\n⏱️ **Timing Metrics:**"
	for name, timing := range timings {
		if timing.Count > 0 {
			text += fmt.Sprintf("\n• %s: %s avg (%d ops)",
				strings.Replace(name, "_", " ", -1),
				timing.AvgTime.Round(time.Millisecond).String(),
				timing.Count)
		}
	}

	text += "\n\n🔢 **Counters:**"
	for name, counter := range counters {
		if counter.Value > 0 {
			text += fmt.Sprintf("\n• %s: %d (%.1f/min)",
				strings.Replace(name, "_", " ", -1),
				counter.Value,
				counter.Rate)
		}
	}

	text += fmt.Sprintf("\n\n🕒 **Last Updated:** %s",
		queueMetrics.LastUpdated.Format("15:04:05"))

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleSystem(message *tgbotapi.Message) {
	if h.healthMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Health monitor not initialized")
		return
	}

	systemMonitor := h.healthMonitor.GetSystemMonitor()
	if systemMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ System monitor not available")
		return
	}

	// Get current system snapshot
	snapshot, err := systemMonitor.GetSystemSnapshot()
	if err != nil {
		h.logger.WithError(err).Error("Failed to get system snapshot")
		h.bot.SendMessage(message.Chat.ID, "❌ Failed to collect system resources")
		return
	}

	text := fmt.Sprintf(`🖥️ **System Resources**

⚡ **CPU Usage:**
• Total: %.1f%%
• User: %.1f%%
• System: %.1f%%
• Idle: %.1f%%`,
		snapshot.CPU.TotalPercent,
		snapshot.CPU.UserPercent,
		snapshot.CPU.SystemPercent,
		snapshot.CPU.IdlePercent)

	text += fmt.Sprintf(`

💾 **Memory Details:**
• Allocated: %.1f MB
• System Total: %.1f MB
• Heap Allocated: %.1f MB
• Heap System: %.1f MB
• Stack In Use: %.1f MB
• GC Collections: %d`,
		snapshot.Memory.AllocMB,
		snapshot.Memory.SysMB,
		snapshot.Memory.HeapAllocMB,
		snapshot.Memory.HeapSysMB,
		snapshot.Memory.StackInUseMB,
		snapshot.Memory.NumGC)

	if !snapshot.Memory.LastGC.IsZero() {
		text += fmt.Sprintf("\n• Last GC: %s ago",
			time.Since(snapshot.Memory.LastGC).Round(time.Second).String())
	}

	text += "\n\n💿 **Disk Usage:**"
	for path, disk := range snapshot.Disk {
		text += fmt.Sprintf("\n• **%s**: %s / %s (%.1f%%)",
			strings.Title(path),
			monitoring.FormatBytes(disk.UsedBytes),
			monitoring.FormatBytes(disk.TotalBytes),
			disk.UsedPercent)
		
		if disk.InodeTotal > 0 {
			inodePercent := float64(disk.InodeUsed) / float64(disk.InodeTotal) * 100
			text += fmt.Sprintf(" | Inodes: %.1f%%", inodePercent)
		}
	}

	text += fmt.Sprintf(`

🔧 **Process Info:**
• PID: %d
• Goroutines: %d
• OS Threads: %d
• File Descriptors: %d
• Virtual Memory: %.1f MB
• Resident Memory: %.1f MB
• Uptime: %s`,
		snapshot.Process.PID,
		snapshot.Process.Goroutines,
		snapshot.Process.Threads,
		snapshot.Process.FDs,
		snapshot.Process.VMemMB,
		snapshot.Process.RSSMemMB,
		snapshot.Process.Uptime.Round(time.Second).String())

	// Add load average if available (Linux)
	if len(snapshot.LoadAvg) == 3 {
		text += fmt.Sprintf("\n• Load Average: %.2f, %.2f, %.2f (1m, 5m, 15m)",
			snapshot.LoadAvg[0], snapshot.LoadAvg[1], snapshot.LoadAvg[2])
	}

	text += fmt.Sprintf("\n\n🕒 **Captured:** %s",
		snapshot.Timestamp.Format("15:04:05"))

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleExtract(message *tgbotapi.Message) {
	// Send immediate response to user
	text := `🔄 **Starting Direct Extraction**

📦 Running extraction on files in: app/extraction/files/all/
⚡ Using direct extraction method
🔍 Looking for .zip and .rar files...`

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)

	// Run extraction directly using extract.go
	go func() {
		defer func() {
			if r := recover(); r != nil {
				h.logger.Errorf("Extraction panic recovered: %v", r)
				h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ **Extraction Error**: %v", r))
			}
		}()
		
		h.logger.Info("Starting direct extraction using extract.ExtractArchives()")
		extract.ExtractArchives()
		h.logger.Info("Direct extraction completed")
		
		// Send completion message
		completionText := `✅ **Extraction Completed**

📦 Direct extraction process finished
📁 Check: app/extraction/files/pass/ for extracted password files
🔍 Processed all .zip and .rar files in: app/extraction/files/all/`

		completionOptions := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, completionText, completionOptions)
	}()
}

func (h *Handlers) handleFull(message *tgbotapi.Message) {
	// Check if user is authorized
	if !h.auth.IsAuthorized(message.From.ID) {
		h.bot.SendMessage(message.Chat.ID, "❌ Unauthorized. This command is only available to admins.")
		return
	}

	// Send initial response
	text := `🚀 **Starting Full Pipeline Process**

📋 **Process Flow:**
  1. **Extract**: Processing archives → pass files
  2. **Convert**: Processing pass files → final output
  3. **Store**: Running data pipeline (filter, merge, database)

⚡ Starting extraction phase...`

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)

	// Run full pipeline in goroutine to avoid blocking bot
	go func() {
		defer func() {
			if r := recover(); r != nil {
				h.logger.WithField("panic", r).Error("Panic in full pipeline process")
			}
		}()

		// Phase 1: Extract
		h.logger.Info("Full pipeline - Starting extraction phase")
		h.bot.SendMessage(message.Chat.ID, "🔧 **Extract Started**")
		
		extract.ExtractArchives()
		
		h.logger.Info("Full pipeline - Extraction phase completed")
		h.bot.SendMessage(message.Chat.ID, "✅ **Extract Completed**")

		// Phase 2: Convert
		h.logger.Info("Full pipeline - Starting conversion phase")  
		h.bot.SendMessage(message.Chat.ID, "⚙️ **Convert Started**")

		// Count files in pass directory for conversion
		filesInPass := h.countFilesInDirectory("app/extraction/files/pass")
		
		if filesInPass > 0 {
			// Run conversion using existing conversion logic
			if h.conversionWorker != nil {
				outputFile := fmt.Sprintf("converted_output_%s.txt", time.Now().Format("20060102_150405"))
				
				// Create conversion job
				convertJob := &pipeline.Job{
					ID:        fmt.Sprintf("full_convert_%s", time.Now().Format("20060102_150405")),
					Type:      pipeline.JobTypeConversion,
					Task:      &models.Task{
						ID:       fmt.Sprintf("full_task_%s", time.Now().Format("20060102_150405")),
						FileName: outputFile,
						Status:   models.TaskStatusPending,
					},
					Status:    pipeline.JobStatusPending,
					Priority:  pipeline.PriorityNormal,
					CreatedAt: time.Now(),
				}
				
				ctx := context.Background()
				err := h.conversionWorker.Process(ctx, convertJob)
				
				if err != nil {
					h.logger.WithError(err).Error("Full pipeline - Conversion failed")
					h.bot.SendMessage(message.Chat.ID, "❌ **Convert Failed**: "+err.Error())
					return
				}
			}
		}

		h.logger.Info("Full pipeline - Conversion phase completed")
		h.bot.SendMessage(message.Chat.ID, "✅ **Convert Completed**")

		// Phase 3: Store Pipeline
		h.logger.Info("Full pipeline - Starting store pipeline phase")
		
		// Create StoreService instance with integrated logger function
		storeLogger := func(format string, args ...interface{}) {
			h.logger.Infof(format, args...)
			// Send store pipeline messages to user
			logMessage := fmt.Sprintf(format, args...)
			h.bot.SendMessage(message.Chat.ID, logMessage)
		}

		storeService := extraction.NewStoreService(storeLogger)
		defer storeService.Close()

		// Run store pipeline
		ctx := context.Background()
		err := storeService.RunPipeline(ctx)
		
		if err != nil {
			h.logger.WithError(err).Error("Full pipeline - Store pipeline failed")
			h.bot.SendMessage(message.Chat.ID, "❌ **Store Pipeline Failed**: "+err.Error())
			return
		}

		h.logger.Info("Full pipeline - All phases completed successfully")
		
		// Final completion message
		completionText := `🎉 **Full Pipeline Completed Successfully**

✅ **All Phases Completed:**
  • Extract: Archives processed
  • Convert: Pass files converted  
  • Store: Data pipeline executed

📁 Check output directories for results`

		completionOptions := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, completionText, completionOptions)
	}()
}

func (h *Handlers) handleConvert(message *tgbotapi.Message, args string) {
	if h.conversionWorker == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Conversion worker not initialized")
		return
	}

	outputFile := "output.txt"
	if args != "" {
		outputFile = args
	}

	// Count files in pass directory
	filesInPass := h.countFilesInDirectory("app/extraction/files/pass")
	
	if filesInPass == 0 {
		text := `❌ **No Files to Convert**

📂 No files found in conversion queue
📁 Directory checked: app/extraction/files/pass/ (0 files)

💡 Run extraction first to populate the conversion queue`

		options := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
		return
	}

	text := fmt.Sprintf(`🔄 **Manual Conversion Started**

📊 **Status:**
  • Files to convert: %d
  • Output file: %s
  • Conversion worker: Starting...

📂 **Process:**
  1. Processing files from extraction/files/pass/
  2. Running convert.go -f files/pass %s
  3. Generating output and moving files to appropriate directories

⏳ Processing... You'll be notified when complete.`, filesInPass, outputFile, outputFile)

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)

	// Create a dummy task for conversion (since conversion works on directory, not specific task)
	dummyTask := &models.Task{
		ID:       fmt.Sprintf("manual_convert_%d", time.Now().Unix()),
		UserID:   message.From.ID,
		ChatID:   message.Chat.ID,
		FileName: outputFile,
		Status:   models.TaskStatusDownloaded, // Ready for processing
	}

	// Create a job for the conversion worker
	job := &pipeline.Job{
		ID:        fmt.Sprintf("manual_convert_%d", time.Now().Unix()),
		Type:      pipeline.JobTypeConversion,
		Task:      dummyTask,
		Status:    pipeline.JobStatusPending,
		Priority:  pipeline.PriorityHigh,
		CreatedAt: time.Now(),
	}
	
	// Process the conversion in a goroutine to avoid blocking the bot
	go func() {
		ctx := context.Background()
		err := h.conversionWorker.Process(ctx, job)
		
		var notificationText string
		if err != nil {
			h.logger.WithField("task_id", dummyTask.ID).
				WithError(err).
				Error("Manual conversion failed")
			
			notificationText = fmt.Sprintf(`❌ **Conversion Failed**

📁 Output file: %s
🚨 Error: %v

💡 Check logs for more details`, outputFile, err)
		} else {
			h.logger.WithField("task_id", dummyTask.ID).
				Info("Manual conversion completed successfully")
			
			// Check results in special directories
			doneCount := h.countFilesInDirectory("app/extraction/files/done")
			errorsCount := h.countFilesInDirectory("app/extraction/files/errors") 
			etbanksCount := h.countFilesInDirectory("app/extraction/files/etbanks")
			
			notificationText = fmt.Sprintf(`✅ **Conversion Completed**

📁 Output file: %s
📊 **Results:**
  • Done (with credentials): %d files
  • Errors (quarantined): %d files  
  • ETBanks (search hits): %d files

📂 Check app/extraction/ directories for detailed results`, outputFile, doneCount, errorsCount, etbanksCount)
		}
		
		options := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, notificationText, options)
	}()

	h.logger.WithField("user_id", message.From.ID).
		WithField("files_in_pass", filesInPass).
		WithField("output_file", outputFile).
		Info("Manual conversion triggered by admin")
}

func (h *Handlers) handleStore(message *tgbotapi.Message) {
	// Authentication already validated in HandleCommand method
	userID := message.From.ID
	username := message.From.UserName
	
	// Initial status message to user
	statusText := `🏪 **Store Pipeline Starting**

📊 **Status:**
  • Pipeline: Initializing StoreService
  • Stage: Preparation
  • Auth: ✅ Admin authenticated

📂 **Process:**
  1. File Merger (text files → single output)
  2. Valuable Extraction (betting URLs → betting file)  
  3. Database Filter & Storage (MySQL/SQLite)

⏳ Initializing... You'll be notified of progress.`

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, statusText, options)

	// Create logger function that integrates with bot's logger and sends status updates
	storeLogger := func(format string, args ...interface{}) {
		logMessage := fmt.Sprintf(format, args...)
		
		// Log to bot's structured logger
		h.logger.WithField("user_id", userID).
			WithField("username", username).
			WithField("component", "StoreService").
			Info(logMessage)
		
		// Send stage progress updates to user
		if strings.Contains(logMessage, "===") {
			stage := strings.Trim(strings.Replace(logMessage, "=", "", -1), " ")
			progressText := fmt.Sprintf(`🔄 **Store Pipeline Progress**

📊 **Current Stage:** %s
⏳ Processing... Please wait for completion notification.`, stage)
			
			h.bot.SendMessageWithOptions(message.Chat.ID, progressText, options)
		}
	}

	// Create StoreService instance with integrated logger
	storeService := extraction.NewStoreService(storeLogger)
	defer storeService.Close()

	// Run pipeline in goroutine to avoid blocking bot
	go func() {
		ctx := context.Background()
		
		// Execute the complete pipeline
		err := storeService.RunPipeline(ctx)
		
		var notificationText string
		if err != nil {
			h.logger.WithField("user_id", userID).
				WithField("username", username).
				WithError(err).
				Error("Store pipeline failed")
			
			notificationText = fmt.Sprintf(`❌ **Store Pipeline Failed**

🚨 **Error:** %v

🔍 **Troubleshooting:**
  • Check input directory has .txt files
  • Verify database connectivity
  • Review logs for detailed error information

💡 Contact admin if error persists.`, err)
		} else {
			h.logger.WithField("user_id", userID).
				WithField("username", username).
				Info("Store pipeline completed successfully")
			
			notificationText = `✅ *Store Pipeline Completed*

📊 *Results:*
• ✅ File Merger: Combined text files successfully
• ✅ Valuable Extraction: Betting URLs extracted
• ✅ Database Storage: Data filtered and stored

📁 *Output Files:*
• Merged data in files/Sorted\_toshare/
• Betting URLs in files/bettings/
• Database records inserted successfully

🎉 Pipeline execution complete!`
		}
		
		h.bot.SendMessageWithOptions(message.Chat.ID, notificationText, options)
	}()

	h.logger.WithField("user_id", userID).
		WithField("username", username).
		Info("Store pipeline triggered by admin")
}

func (h *Handlers) handleProcess(message *tgbotapi.Message) {
	// Validate core system components are initialized
	if h.taskStore == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Task store not initialized - system not ready")
		return
	}
	
	if h.extractionWorker == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Extraction worker not initialized")
		return
	}
	
	if h.conversionWorker == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Conversion worker not initialized")
		return
	}
	
	// Validate critical directories exist and are accessible
	requiredDirs := []string{
		"app/extraction/files/all",
		"app/extraction/files/pass",
		"app/extraction/files/done",
		"app/extraction/files/errors",
	}
	
	for _, dir := range requiredDirs {
		if !h.validateDirectoryAccess(dir) {
			h.logger.WithField("directory", dir).Error("Critical directory not accessible for process command")
			h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ System error: Directory %s not accessible", dir))
			return
		}
	}
	
	// Check system health before starting intensive process
	if h.healthMonitor != nil {
		healthCheck := h.healthMonitor.GetLastHealthCheck()
		if healthCheck != nil && healthCheck.Status == "unhealthy" {
			h.bot.SendMessage(message.Chat.ID, "❌ System unhealthy - process command blocked for safety")
			return
		}
	}

	// Check if extraction is already running
	if h.extractionWorker.IsRunning() {
		text := `⚠️ **Process Command Blocked**

🔄 An extraction is currently in progress
⏱️ Please wait for current operations to complete

💡 Process command runs extraction followed by conversion automatically`

		options := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
		return
	}

	// Get tasks that are ready for processing (downloaded but not processed)
	downloadedTasks, err := h.taskStore.GetByStatus(models.TaskStatusDownloaded)
	if err != nil {
		h.logger.WithError(err).Error("Failed to get downloaded tasks for process command")
		h.bot.SendMessage(message.Chat.ID, "❌ Failed to check for available files")
		return
	}

	if len(downloadedTasks) == 0 {
		text := `❌ **No Files to Process**

📂 No downloaded files found ready for processing
📁 Current status: All files are either:
  • Still downloading
  • Already processed
  • Failed processing

💡 Upload files first, wait for download to complete, then run /process`

		options := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
		return
	}

	text := fmt.Sprintf(`🔄 **Automated Process Started**

📊 **Status:**
  • Files ready for processing: %d
  • Process: Extract → Convert (automatic)
  • Workers: Starting orchestration...

📂 **Process Flow:**
  1. **Extract**: archives → extraction/files/pass/
  2. **Convert**: pass files → final output + categorization
  3. **Complete**: Notify results and file locations

⏳ Processing... You'll be notified at each stage.`, len(downloadedTasks))

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)

	// Process the first downloaded task
	task := downloadedTasks[0]
	
	// Create extraction job
	extractJob := &pipeline.Job{
		ID:        fmt.Sprintf("process_extract_%s", task.ID),
		Type:      pipeline.JobTypeExtraction,
		Task:      task,
		Status:    pipeline.JobStatusPending,
		Priority:  pipeline.PriorityHigh,
		CreatedAt: time.Now(),
	}
	
	// Process extraction and conversion sequentially in a goroutine
	go func() {
		ctx := context.Background()
		
		// Step 1: Extraction
		h.logger.WithField("task_id", task.ID).
			WithField("process_type", "orchestrated").
			Info("Starting orchestrated extraction phase")

		err := h.extractionWorker.Process(ctx, extractJob)
		if err != nil {
			h.logger.WithField("task_id", task.ID).
				WithError(err).
				Error("Orchestrated extraction failed")
			
			// Update task status to failed
			h.taskStore.UpdateStatus(task.ID, models.TaskStatusFailed, fmt.Sprintf("Process extraction failed: %v", err))
			
			failureText := fmt.Sprintf(`❌ **Process Failed (Extraction Stage)**

📁 File: %s
🚨 Error: %v

💡 Check logs for more details. You can try manual /extract command.`, task.FileName, err)
			
			options := &MessageOptions{
				ParseMode: "Markdown",
			}
			h.bot.SendMessageWithOptions(message.Chat.ID, failureText, options)
			return
		}

		// Step 1 Complete - Notify extraction success
		extractCompleteText := fmt.Sprintf(`✅ **Extraction Complete**

📁 File: %s
📂 Status: Successfully extracted
🔄 **Next**: Starting conversion automatically...`, task.FileName)

		options := &MessageOptions{
			ParseMode: "Markdown",
		}
		h.bot.SendMessageWithOptions(message.Chat.ID, extractCompleteText, options)

		h.logger.WithField("task_id", task.ID).
			Info("Orchestrated extraction completed, starting conversion")

		// Step 2: Conversion
		// Count files in pass directory for conversion
		filesInPass := h.countFilesInDirectory("app/extraction/files/pass")
		
		if filesInPass == 0 {
			conversionFailText := `❌ **Process Failed (Conversion Stage)**

📂 No files found in conversion queue after extraction
💡 This may indicate an extraction issue. Check app/extraction/files/pass/ directory.`

			h.bot.SendMessageWithOptions(message.Chat.ID, conversionFailText, options)
			return
		}

		// Create conversion job
		outputFile := "output.txt"
		conversionTask := &models.Task{
			ID:       fmt.Sprintf("process_convert_%s", task.ID),
			UserID:   message.From.ID,
			ChatID:   message.Chat.ID,
			FileName: outputFile,
			Status:   models.TaskStatusDownloaded,
		}

		convertJob := &pipeline.Job{
			ID:        fmt.Sprintf("process_convert_%s", task.ID),
			Type:      pipeline.JobTypeConversion,
			Task:      conversionTask,
			Status:    pipeline.JobStatusPending,
			Priority:  pipeline.PriorityHigh,
			CreatedAt: time.Now(),
		}

		err = h.conversionWorker.Process(ctx, convertJob)
		if err != nil {
			h.logger.WithField("task_id", task.ID).
				WithError(err).
				Error("Orchestrated conversion failed")

			conversionFailText := fmt.Sprintf(`❌ **Process Failed (Conversion Stage)**

📁 Output file: %s
🚨 Error: %v

💡 Extraction succeeded, but conversion failed. Check logs for details.`, outputFile, err)

			h.bot.SendMessageWithOptions(message.Chat.ID, conversionFailText, options)
			return
		}

		// Step 2 Complete - Final success notification
		h.logger.WithField("task_id", task.ID).
			Info("Orchestrated process completed successfully")

		// Check results in output directories  
		doneCount := h.countFilesInDirectory("app/extraction/files/done")
		errorsCount := h.countFilesInDirectory("app/extraction/files/errors")
		etbanksCount := h.countFilesInDirectory("app/extraction/files/etbanks")

		finalText := fmt.Sprintf(`🎉 **Process Completed Successfully**

📁 Original File: %s
📄 Output File: %s

📊 **Final Results:**
  • Done (with credentials): %d files
  • Errors (quarantined): %d files  
  • ETBanks (search hits): %d files

📂 **Locations:**
  • Main output: app/extraction/files/txt/
  • Categorized results: app/extraction/ subdirectories

✅ **Process Summary:** Extract → Convert → Complete`, task.FileName, outputFile, doneCount, errorsCount, etbanksCount)

		h.bot.SendMessageWithOptions(message.Chat.ID, finalText, options)
	}()

	h.logger.WithField("user_id", message.From.ID).
		WithField("task_id", task.ID).
		WithField("file_name", task.FileName).
		Info("Orchestrated process triggered by admin")
}

func (h *Handlers) handleQueue(message *tgbotapi.Message) {
	if h.taskStore == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Task store not initialized")
		return
	}

	// Get tasks by status
	pendingTasks, err := h.taskStore.GetByStatus(models.TaskStatusPending)
	if err != nil {
		h.logger.WithError(err).Error("Failed to get pending tasks")
		h.bot.SendMessage(message.Chat.ID, "❌ Failed to retrieve pending tasks")
		return
	}

	downloadedTasks, err := h.taskStore.GetByStatus(models.TaskStatusDownloaded)
	if err != nil {
		h.logger.WithError(err).Error("Failed to get downloaded tasks")
		h.bot.SendMessage(message.Chat.ID, "❌ Failed to retrieve downloaded tasks")
		return
	}

	// Count files in extraction directories
	filesInAll := h.countFilesInDirectory("app/extraction/files/all")
	filesInPass := h.countFilesInDirectory("app/extraction/files/pass")
	filesInTemp := h.countFilesInDirectory("temp")

	text := fmt.Sprintf(`📋 **Processing Queue Status**

📥 **Download Queue:**
• Pending downloads: %d tasks
• Files in temp/: %d files

🔄 **Extraction Queue:**
• Downloaded (ready for extraction): %d tasks  
• Files in extraction/files/all/: %d files

⚙️ **Conversion Queue:**
• Files in extraction/files/pass/: %d files

📊 **Queue Details:**`,
		len(pendingTasks),
		filesInTemp,
		len(downloadedTasks),
		filesInAll,
		filesInPass)

	// Add details for downloaded tasks awaiting manual processing
	if len(downloadedTasks) > 0 {
		text += "\n\n🔽 **Downloaded Files Awaiting Manual Processing:**"
		for i, task := range downloadedTasks {
			if i >= 5 { // Limit to first 5 tasks
				text += fmt.Sprintf("\n• ...and %d more", len(downloadedTasks)-5)
				break
			}
			text += fmt.Sprintf("\n• %s (%s, %.1fMB) - Task: %s",
				task.FileName,
				strings.ToUpper(task.FileType),
				float64(task.FileSize)/(1024*1024),
				task.ID)
		}
	}

	// Add details for pending downloads if any
	if len(pendingTasks) > 0 {
		text += "\n\n⏳ **Pending Downloads:**"
		for i, task := range pendingTasks {
			if i >= 3 { // Limit to first 3 tasks
				text += fmt.Sprintf("\n• ...and %d more", len(pendingTasks)-3)
				break
			}
			text += fmt.Sprintf("\n• %s (%s, %.1fMB) - Task: %s",
				task.FileName,
				strings.ToUpper(task.FileType),
				float64(task.FileSize)/(1024*1024),
				task.ID)
		}
	}

	text += "\n\n💡 **Next Actions:**\n• Use /extract to process downloaded files\n• Use /convert after extraction completes"

	options := &MessageOptions{
		ParseMode: "",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleStop(message *tgbotapi.Message) {
	text := `⛔ **Force Stop Initiated**

🔄 Stopping all operations...
🗑️ Clearing queues...
✅ All processes stopped.

*Note: Worker management will be implemented in the pipeline phase*`

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleCleanup(message *tgbotapi.Message) {
	errorsDir := "app/extraction/files/errors"
	nopassDir := "app/extraction/files/nopass"
	filterErrorsDir := "app/extraction/files/filter_errors"
	backupsDir := "app/extraction/files/backups"
	
	errorsCount := h.cleanDirectory(errorsDir)
	nopassCount := h.cleanDirectory(nopassDir)
	filterErrorsCount := h.cleanDirectory(filterErrorsDir)
	backupsCount := h.cleanDirectory(backupsDir)
	
	text := fmt.Sprintf(`🧹 **Cleanup Complete**

🗑️ Removed from errors/: %d files
🗑️ Removed from nopass/: %d files
🗑️ Removed from filter_errors/: %d files
🗑️ Removed from backups/: %d files
✅ Cleanup successful!`, errorsCount, nopassCount, filterErrorsCount, backupsCount)

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleMove(message *tgbotapi.Message) {
	// Check if Local Bot API directory exists
	localAPIDir := "5773867447:AAFi7VjSS-RwtYm-k9HjkfeOxkk6Oh2TSzY/documents"
	if _, err := os.Stat(localAPIDir); os.IsNotExist(err) {
		h.bot.SendMessage(message.Chat.ID, "❌ Local Bot API directory not found. No files to move.")
		return
	}

	// Send initial progress message
	progressMsgResp, err := h.bot.bot.Send(tgbotapi.NewMessage(message.Chat.ID, "🔄 Starting file move operation..."))
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Failed to send progress message")
		return
	}

	// Get all files in Local Bot API directory
	files, err := filepath.Glob(filepath.Join(localAPIDir, "*"))
	if err != nil {
		h.bot.EditMessage(message.Chat.ID, progressMsgResp.MessageID, "❌ Failed to scan Local Bot API directory", nil)
		return
	}

	if len(files) == 0 {
		h.bot.EditMessage(message.Chat.ID, progressMsgResp.MessageID, "✅ No files found in Local Bot API directory", nil)
		return
	}

	// Create destination directories
	txtDir := "app/extraction/files/txt"
	allDir := "app/extraction/files/all"
	os.MkdirAll(txtDir, 0755)
	os.MkdirAll(allDir, 0755)

	var movedFiles []string
	var skippedFiles []string
	var errorFiles []string

	// Get task mapping for original filenames
	taskMap := h.getTaskFilenameMapping()

	for _, filePath := range files {
		fileInfo, err := os.Stat(filePath)
		if err != nil || fileInfo.IsDir() {
			continue
		}

		localAPIFilename := filepath.Base(filePath)
		originalFilename := h.getOriginalFilename(localAPIFilename, taskMap)
		
		// Determine destination directory based on extension
		var destDir string
		ext := strings.ToLower(filepath.Ext(originalFilename))
		switch ext {
		case ".txt":
			destDir = txtDir
		case ".zip", ".rar":
			destDir = allDir
		default:
			destDir = allDir
		}

		// Handle filename conflicts
		destPath := filepath.Join(destDir, originalFilename)
		finalPath := h.resolveFilenameConflict(destPath, originalFilename)
		
		// Move file
		if err := os.Rename(filePath, finalPath); err != nil {
			h.logger.WithError(err).
				WithField("source", filePath).
				WithField("dest", finalPath).
				Error("Failed to move file")
			errorFiles = append(errorFiles, fmt.Sprintf("%s (move failed)", localAPIFilename))
		} else {
			// Update task metadata if available
			h.updateTaskLocalAPIPath(localAPIFilename, "")
			movedFiles = append(movedFiles, fmt.Sprintf("%s → %s", localAPIFilename, filepath.Base(finalPath)))
		}
	}

	// Create summary message
	summary := fmt.Sprintf("📁 **File Move Operation Complete**\n\n")
	
	if len(movedFiles) > 0 {
		summary += fmt.Sprintf("✅ **Moved %d files:**\n", len(movedFiles))
		for i, file := range movedFiles {
			if i < 10 { // Limit display to avoid message length issues
				summary += fmt.Sprintf("• %s\n", file)
			} else {
				summary += fmt.Sprintf("• ... and %d more files\n", len(movedFiles)-i)
				break
			}
		}
		summary += "\n"
	}

	if len(skippedFiles) > 0 {
		summary += fmt.Sprintf("⚠️ **Skipped %d files:**\n", len(skippedFiles))
		for _, file := range skippedFiles {
			summary += fmt.Sprintf("• %s\n", file)
		}
		summary += "\n"
	}

	if len(errorFiles) > 0 {
		summary += fmt.Sprintf("❌ **Failed %d files:**\n", len(errorFiles))
		for _, file := range errorFiles {
			summary += fmt.Sprintf("• %s\n", file)
		}
		summary += "\n"
	}

	summary += "📂 **File Distribution:**\n"
	summary += fmt.Sprintf("• TXT files: %s\n", txtDir)
	summary += fmt.Sprintf("• Archive files: %s\n", allDir)

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.EditMessage(message.Chat.ID, progressMsgResp.MessageID, summary, options)
}

func (h *Handlers) handleExit(message *tgbotapi.Message) {
	text := `🔌 **Safe Shutdown Initiated**

💾 Saving active tasks...
⏹️ Stopping workers gracefully...
✅ Ready for shutdown.

*Note: Graceful shutdown will be implemented in the pipeline phase*`

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleUnknownCommand(message *tgbotapi.Message, command string) {
	text := fmt.Sprintf("❓ Unknown command: /%s\n\nUse /commands to see available commands.", command)
	h.bot.SendMessage(message.Chat.ID, text)
}

func (h *Handlers) getDirStatus(dir string) string {
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		return "❌ Missing"
	}
	return "✅ Ready"
}

func (h *Handlers) validateDirectoryAccess(dir string) bool {
	// Check if directory exists
	info, err := os.Stat(dir)
	if os.IsNotExist(err) {
		// Try to create directory if it doesn't exist
		if err := os.MkdirAll(dir, 0755); err != nil {
			h.logger.WithError(err).WithField("directory", dir).Error("Failed to create directory")
			return false
		}
		return true
	}
	
	if err != nil {
		h.logger.WithError(err).WithField("directory", dir).Error("Failed to access directory")
		return false
	}
	
	// Verify it's actually a directory
	if !info.IsDir() {
		h.logger.WithField("directory", dir).Error("Path exists but is not a directory")
		return false
	}
	
	// Test write permissions by attempting to create a temp file
	tempFile := filepath.Join(dir, ".access_test")
	if file, err := os.Create(tempFile); err != nil {
		h.logger.WithError(err).WithField("directory", dir).Warn("Directory not writable")
		return false
	} else {
		file.Close()
		os.Remove(tempFile) // Clean up test file
	}
	
	return true
}

func (h *Handlers) countFilesInDirectory(dir string) int {
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		return 0
	}
	
	files, err := filepath.Glob(filepath.Join(dir, "*"))
	if err != nil {
		h.logger.WithError(err).WithField("directory", dir).Error("Failed to list files")
		return 0
	}
	
	count := 0
	for _, file := range files {
		if info, err := os.Stat(file); err == nil && !info.IsDir() {
			count++
		}
	}
	
	return count
}

func (h *Handlers) startFileDownload(task *models.Task) error {
	if h.pipelineCoordinator == nil {
		return fmt.Errorf("pipeline coordinator not initialized")
	}

	h.logger.WithField("task_id", task.ID).
		WithField("file_name", task.FileName).
		Info("Submitting task to pipeline for processing")

	// Submit task to pipeline coordinator for proper processing
	if err := h.pipelineCoordinator.SubmitFileTask(task); err != nil {
		h.logger.WithError(err).
			WithField("task_id", task.ID).
			Error("Failed to submit task to pipeline")
		
		// Update task status to failed
		h.taskStore.UpdateStatus(task.ID, models.TaskStatusFailed, err.Error())
		
		// Send failure notification
		h.sendDownloadFailureNotification(task, err)
		return err
	}

	h.logger.WithField("task_id", task.ID).
		Info("Task submitted to pipeline successfully")

	return nil
}

func (h *Handlers) sendDownloadSuccessNotification(task *models.Task) {
	successText := fmt.Sprintf(`✅ **Download Complete**

🆔 **Task ID:** %s
📄 **File:** %s
📊 **Size:** %.2fMB
📍 **Location:** temp/%s_%s

🔄 **Next Steps:**
• File ready for manual processing
• Use /extract to trigger extraction
• Use /convert after extraction completes

📋 **Status:** Downloaded and ready`, 
		task.ID,
		task.FileName,
		float64(task.FileSize)/(1024*1024),
		task.ID,
		task.FileName)

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(task.ChatID, successText, options)
}

func (h *Handlers) sendDownloadFailureNotification(task *models.Task, err error) {
	failureText := fmt.Sprintf(`❌ **Download Failed**

🆔 **Task ID:** %s
📄 **File:** %s
⚠️ **Error:** %s

🔄 **What to do:**
• Check network connection
• Try uploading the file again
• Contact admin if problem persists`, 
		task.ID,
		task.FileName,
		err.Error())

	options := &MessageOptions{
		ParseMode: "Markdown",
	}
	h.bot.SendMessageWithOptions(task.ChatID, failureText, options)
}

// Simple job wrapper to implement the Job interface
type simpleJob struct {
	task      *models.Task
	status    string
	error     string
	createdAt time.Time
	startedAt time.Time
	endedAt   time.Time
}

func (j *simpleJob) GetID() string {
	return j.task.ID
}

func (j *simpleJob) GetTask() *models.Task {
	return j.task
}

func (j *simpleJob) GetType() string {
	return "download"
}

func (j *simpleJob) SetStatus(status string) {
	j.status = status
}

func (j *simpleJob) SetError(error string) {
	j.error = error
}

func (j *simpleJob) GetCreatedAt() time.Time {
	return j.createdAt
}

func (j *simpleJob) SetStartedAt(t time.Time) {
	j.startedAt = t
}

func (j *simpleJob) SetEndedAt(t time.Time) {
	j.endedAt = t
}

// TaskStatistics holds task status counts
type TaskStatistics struct {
	Total      int
	Pending    int
	Downloaded int
	Completed  int
	Failed     int
}

func (h *Handlers) getTaskStatistics() (*TaskStatistics, error) {
	if h.taskStore == nil {
		return nil, fmt.Errorf("task store not initialized")
	}

	// Use the efficient GetStats method from TaskStore
	dbStats, err := h.taskStore.GetStats()
	if err != nil {
		return nil, fmt.Errorf("failed to get task statistics: %w", err)
	}

	stats := &TaskStatistics{
		Pending:    dbStats[string(models.TaskStatusPending)],
		Downloaded: dbStats[string(models.TaskStatusDownloaded)],
		Completed:  dbStats[string(models.TaskStatusCompleted)],
		Failed:     dbStats[string(models.TaskStatusFailed)],
	}
	
	// Calculate total
	stats.Total = stats.Pending + stats.Downloaded + stats.Completed + stats.Failed

	return stats, nil
}

func (h *Handlers) cleanDirectory(dir string) int {
	count := 0
	if _, err := os.Stat(dir); os.IsNotExist(err) {
		return count
	}
	
	files, err := filepath.Glob(filepath.Join(dir, "*"))
	if err != nil {
		h.logger.WithError(err).WithField("directory", dir).Error("Failed to list files for cleanup")
		return count
	}
	
	for _, file := range files {
		if err := os.Remove(file); err != nil {
			h.logger.WithError(err).WithField("file", file).Warn("Failed to remove file during cleanup")
		} else {
			count++
			h.logger.WithField("file", file).Debug("File removed during cleanup")
		}
	}
	
	return count
}

func (h *Handlers) handleAlerts(message *tgbotapi.Message) {
	if h.healthMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Health monitor not initialized")
		return
	}

	alertManager := h.healthMonitor.GetAlertManager()
	activeAlerts := alertManager.GetActiveAlerts()
	alertStats := alertManager.GetAlertStats()

	if len(activeAlerts) == 0 {
		alertText := fmt.Sprintf(`✅ **No Active Alerts**

📊 **Alert Statistics:**
• Alert Rules: %d total, %d enabled
• Active Alerts: %d
• Alert History: %d entries

🔍 All systems operating normally.`,
			alertStats["total_rules"],
			alertStats["enabled_rules"],
			alertStats["active_alerts"],
			alertStats["history_size"])

		options := &MessageOptions{ParseMode: "Markdown"}
		h.bot.SendMessageWithOptions(message.Chat.ID, alertText, options)
		return
	}

	alertText := fmt.Sprintf(`🚨 **Active Alerts (%d)**

`, len(activeAlerts))

	for i, alert := range activeAlerts {
		var levelEmoji string
		switch alert.Level {
		case monitoring.AlertLevelCritical:
			levelEmoji = "🚨"
		case monitoring.AlertLevelWarning:
			levelEmoji = "⚠️"
		case monitoring.AlertLevelInfo:
			levelEmoji = "ℹ️"
		default:
			levelEmoji = "📢"
		}

		alertText += fmt.Sprintf(`%s **Alert #%d**
🔍 **Type:** %s
📊 **Level:** %s
🕐 **Since:** %s
📝 **Message:** %s`,
			levelEmoji,
			i+1,
			string(alert.Type),
			string(alert.Level),
			alert.Timestamp.Format("2006-01-02 15:04:05"),
			alert.Message)

		if alert.Count > 1 {
			alertText += fmt.Sprintf("\n🔢 **Count:** %d occurrences", alert.Count)
		}

		if alert.Component != "" {
			alertText += fmt.Sprintf("\n🔧 **Component:** %s", alert.Component)
		}

		alertText += "\n\n"
	}

	alertText += fmt.Sprintf(`📊 **Statistics:**
• Total Rules: %d (%d enabled)
• Alert History: %d entries

Use /alertrules to view alert rules`,
		alertStats["total_rules"],
		alertStats["enabled_rules"],
		alertStats["history_size"])

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, alertText, options)
}

func (h *Handlers) handleAlertRules(message *tgbotapi.Message) {
	if h.healthMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Health monitor not initialized")
		return
	}

	alertManager := h.healthMonitor.GetAlertManager()
	alertStats := alertManager.GetAlertStats()

	rulesText := fmt.Sprintf(`📋 **Alert Rules Configuration**

📊 **Overview:**
• Total Rules: %d
• Enabled Rules: %d
• Active Alerts: %d

🔧 **Default Rules:**
1. **High Memory Usage** ⚠️
   • Threshold: 500MB allocated
   • Cooldown: 5 minutes

2. **Critical Memory Usage** 🚨
   • Threshold: 1GB allocated
   • Cooldown: 2 minutes

3. **High CPU Usage** ⚠️
   • Threshold: 80%% utilization
   • Cooldown: 3 minutes

4. **Low Disk Space** ⚠️
   • Threshold: 85%% usage
   • Cooldown: 10 minutes

5. **Queue Backup** ⚠️
   • Threshold: 50+ items in queue
   • Cooldown: 5 minutes

6. **High Load Average** ⚠️
   • Threshold: 2.0 (5-min avg)
   • Cooldown: 5 minutes

7. **High Goroutine Count** ⚠️
   • Threshold: 1000+ goroutines
   • Cooldown: 5 minutes

8. **High Failure Rate** ⚠️
   • Threshold: 25%% failure rate
   • Cooldown: 10 minutes

🔔 **Notifications:** Real-time alerts sent to all admins
⚡ **Monitoring:** Checks run every 30 seconds`,
		alertStats["total_rules"],
		alertStats["enabled_rules"],
		alertStats["active_alerts"])

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, rulesText, options)
}

func (h *Handlers) handleDiagnostics(message *tgbotapi.Message) {
	if h.healthMonitor == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Health monitor not initialized")
		return
	}

	// Get last diagnostics or trigger new ones
	diagnostics := h.healthMonitor.GetLastDiagnostics()
	
	if diagnostics == nil {
		// No diagnostics run yet, inform user and trigger
		h.bot.SendMessage(message.Chat.ID, "🔍 **Running Initial Diagnostics...**\n\nThis may take a few moments. Please wait...")
		
		// Trigger diagnostics in background and return basic info
		go h.healthMonitor.RunSelfDiagnostics()
		
		diagnosticsText := `🔍 **Self-Diagnostics**

🚀 **Initial diagnostic run started in background.**

📋 **Diagnostic Checks Include:**
• External executable validation (extract.go, convert.go)
• Directory structure integrity
• Database connectivity and health
• Password file availability
• Disk space projections
• Network connectivity tests

⏰ **Next Update:** Results will be available in ~1 minute
💡 **Tip:** Use /diagnostics again to view results`

		options := &MessageOptions{ParseMode: "Markdown"}
		h.bot.SendMessageWithOptions(message.Chat.ID, diagnosticsText, options)
		return
	}

	// Show recent diagnostics results
	var statusEmoji string
	switch diagnostics.OverallStatus {
	case monitoring.HealthStatusHealthy:
		statusEmoji = "✅"
	case monitoring.HealthStatusDegraded:
		statusEmoji = "⚠️"
	case monitoring.HealthStatusUnhealthy:
		statusEmoji = "🚨"
	default:
		statusEmoji = "❓"
	}

	diagnosticsText := fmt.Sprintf(`🔍 **Self-Diagnostics Report**

%s **Overall Status:** %s
🕐 **Last Run:** %s
⏱️ **Duration:** %s
📊 **Checks:** %d completed

`,
		statusEmoji,
		string(diagnostics.OverallStatus),
		diagnostics.Timestamp.Format("2006-01-02 15:04:05"),
		diagnostics.Duration.Round(time.Millisecond).String(),
		len(diagnostics.Results))

	// Show individual results
	diagnosticsText += "📋 **Individual Results:**\n\n"

	for i, result := range diagnostics.Results {
		var resultEmoji string
		switch result.Status {
		case monitoring.HealthStatusHealthy:
			resultEmoji = "✅"
		case monitoring.HealthStatusDegraded:
			resultEmoji = "⚠️"
		case monitoring.HealthStatusUnhealthy:
			resultEmoji = "🚨"
		default:
			resultEmoji = "❓"
		}

		diagnosticsText += fmt.Sprintf(`%s **%d. %s**
   Status: %s
   Message: %s
   Duration: %s

`,
			resultEmoji,
			i+1,
			strings.Title(strings.ReplaceAll(result.Name, "_", " ")),
			string(result.Status),
			result.Message,
			result.Duration.Round(time.Millisecond).String())
	}

	diagnosticsText += `🔄 **Auto-Run:** Every ~5 minutes
💡 **Tip:** Use /health for continuous monitoring
🚨 **Critical Issues:** Automatically generate alerts`

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, diagnosticsText, options)
}

// Dead Letter Queue command handlers

func (h *Handlers) handleDeadLetter(message *tgbotapi.Message) {
	if h.deadLetterQueue == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Dead letter queue not available")
		return
	}

	// Get basic statistics
	stats, err := h.deadLetterQueue.GetStats()
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to get dead letter statistics: %v", err))
		return
	}

	// Get recent entries (last 5)
	retryable, err := h.deadLetterQueue.GetRetryable()
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to get retryable entries: %v", err))
		return
	}

	manual, err := h.deadLetterQueue.GetManualIntervention()
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to get manual intervention entries: %v", err))
		return
	}

	text := fmt.Sprintf(`💀 **Dead Letter Queue Status**

📊 **Overview:**
• Total entries: %d
• Retryable: %d
• Manual intervention: %d
• Oldest entry: %s

🔄 **Recent Retryable Tasks:**`,
		stats["total_count"],
		stats["retryable_count"],
		stats["manual_intervention_count"],
		stats["oldest_entry_age"])

	// Show up to 3 recent retryable entries
	retryableCount := len(retryable)
	if retryableCount > 3 {
		retryableCount = 3
	}

	if retryableCount == 0 {
		text += "\n• No retryable tasks"
	} else {
		for i := 0; i < retryableCount; i++ {
			entry := retryable[i]
			text += fmt.Sprintf("\n• `%s` - %s (%s)", entry.ID[:8], entry.FileName, entry.Reason)
		}
		if len(retryable) > 3 {
			text += fmt.Sprintf("\n• ...and %d more", len(retryable)-3)
		}
	}

	text += "\n\n🚨 **Manual Intervention Required:**"
	
	// Show up to 3 manual intervention entries
	manualCount := len(manual)
	if manualCount > 3 {
		manualCount = 3
	}

	if manualCount == 0 {
		text += "\n• No tasks requiring manual intervention"
	} else {
		for i := 0; i < manualCount; i++ {
			entry := manual[i]
			text += fmt.Sprintf("\n• `%s` - %s (%s)", entry.ID[:8], entry.FileName, entry.Reason)
		}
		if len(manual) > 3 {
			text += fmt.Sprintf("\n• ...and %d more", len(manual)-3)
		}
	}

	text += "\n\n💡 Use `/dlstats` for detailed statistics"

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleDeadLetterStats(message *tgbotapi.Message) {
	if h.deadLetterManager == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Dead letter manager not available")
		return
	}

	stats, err := h.deadLetterManager.GetDetailedStats()
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to get detailed statistics: %v", err))
		return
	}

	text := fmt.Sprintf(`📊 **Dead Letter Queue - Detailed Statistics**

📈 **Summary:**
• Total entries: %d
• Retryable tasks: %d
• Manual intervention: %d
• Oldest entry: %s

🔍 **Breakdown by Reason:**`,
		stats["total_count"],
		stats["retryable_count"],
		stats["manual_intervention_count"],
		stats["oldest_entry_age"])

	if reasonStats, ok := stats["by_reason"].(map[string]int); ok {
		for reason, count := range reasonStats {
			if count > 0 {
				text += fmt.Sprintf("\n• %s: %d", reason, count)
			}
		}
	}

	text += fmt.Sprintf(`

⏰ **Last Updated:** %s

💡 **Management Commands:**
• /dlretry <id> - Retry specific task
• /dlbulkretry <reason> - Bulk retry by reason
• /dlcleanup <days> - Clean old entries`, 
		stats["last_updated"])

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleDeadLetterRetry(message *tgbotapi.Message, args []string) {
	if h.deadLetterManager == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Dead letter manager not available")
		return
	}

	if len(args) == 0 {
		h.bot.SendMessage(message.Chat.ID, "❌ Usage: /dlretry <dead_letter_id>")
		return
	}

	deadLetterID := args[0]

	h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("🔄 Attempting to retry task `%s`...", deadLetterID))

	task, err := h.deadLetterManager.RetryFromDeadLetter(deadLetterID)
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to retry task: %v", err))
		return
	}

	text := fmt.Sprintf("✅ **Task Successfully Retried**\n\n🆔 Task ID: `%s`\n📁 File: %s\n📝 Status: %s\n🔄 Created new task for processing\n\nThe task has been moved from dead letter queue to active processing queue.", 
		task.ID, task.FileName, task.Status)

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleDeadLetterBulkRetry(message *tgbotapi.Message, args []string) {
	if h.deadLetterManager == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Dead letter manager not available")
		return
	}

	if len(args) == 0 {
		h.bot.SendMessage(message.Chat.ID, "❌ Usage: /dlbulkretry <reason> [max_count]\nReasons: max_retries_exceeded, timeout, system_failure")
		return
	}

	reasonStr := args[0]
	maxRetries := 10 // Default limit

	if len(args) > 1 {
		// Parse max retries from second argument
		if args[1] != "" {
			var parseErr error
			maxRetries, parseErr = parseInt(args[1])
			if parseErr != nil || maxRetries <= 0 {
				h.bot.SendMessage(message.Chat.ID, "❌ Invalid max count. Must be a positive number.")
				return
			}
		}
	}

	// Convert string to DeadLetterReason
	var reason storage.DeadLetterReason
	switch reasonStr {
	case "max_retries_exceeded":
		reason = storage.DeadLetterReasonMaxRetriesExceeded
	case "timeout":
		reason = storage.DeadLetterReasonTimeout
	case "system_failure":
		reason = storage.DeadLetterReasonSystemFailure
	case "manual_move":
		reason = storage.DeadLetterReasonManualMove
	default:
		h.bot.SendMessage(message.Chat.ID, "❌ Invalid reason. Valid reasons: max_retries_exceeded, timeout, system_failure, manual_move")
		return
	}

	h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("🔄 Starting bulk retry for reason `%s` (max: %d)...", reasonStr, maxRetries))

	successful, failed, err := h.deadLetterManager.BulkRetryByReason(reason, maxRetries)
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Bulk retry failed: %v", err))
		return
	}

	text := fmt.Sprintf(`📊 **Bulk Retry Results**

🔄 Reason: %s
✅ Successful: %d
❌ Failed: %d

**Successful Retries:**`,
		reasonStr, len(successful), len(failed))

	if len(successful) == 0 {
		text += "\n• None"
	} else {
		for i, id := range successful {
			if i < 5 { // Show max 5
				text += fmt.Sprintf("\n• `%s`", id[:8])
			} else {
				text += fmt.Sprintf("\n• ...and %d more", len(successful)-5)
				break
			}
		}
	}

	if len(failed) > 0 {
		text += "\n\n**Failed Retries:**"
		for i, failure := range failed {
			if i < 3 { // Show max 3 failures
				text += fmt.Sprintf("\n• %s", failure)
			} else {
				text += fmt.Sprintf("\n• ...and %d more", len(failed)-3)
				break
			}
		}
	}

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleDeadLetterCleanup(message *tgbotapi.Message, args []string) {
	if h.deadLetterManager == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Dead letter manager not available")
		return
	}

	if len(args) == 0 {
		h.bot.SendMessage(message.Chat.ID, "❌ Usage: /dlcleanup <days>\nExample: /dlcleanup 30 (removes entries older than 30 days)")
		return
	}

	days, err := parseInt(args[0])
	if err != nil || days <= 0 {
		h.bot.SendMessage(message.Chat.ID, "❌ Invalid number of days. Must be a positive number.")
		return
	}

	duration := time.Duration(days) * 24 * time.Hour

	h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("🧹 Cleaning up dead letter entries older than %d days...", days))

	purgedCount, err := h.deadLetterManager.CleanupOldEntries(duration)
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Cleanup failed: %v", err))
		return
	}

	text := fmt.Sprintf(`🧹 **Dead Letter Queue Cleanup Complete**

🗑️ Removed: %d old entries
📅 Older than: %d days
✅ Cleanup successful!

💡 Only non-retryable entries were removed.
Retryable entries are preserved for potential recovery.`, 
		purgedCount, days)

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

// Helper function to parse integers
func parseInt(s string) (int, error) {
	result := 0
	for _, r := range s {
		if r < '0' || r > '9' {
			return 0, fmt.Errorf("invalid character: %c", r)
		}
		result = result*10 + int(r-'0')
	}
	return result, nil
}

// Helper function to parse command arguments
func parseArgs(argsStr string) []string {
	if argsStr == "" {
		return []string{}
	}
	
	var args []string
	current := ""
	inQuotes := false
	
	for i, r := range argsStr {
		switch r {
		case ' ':
			if inQuotes {
				current += string(r)
			} else if current != "" {
				args = append(args, current)
				current = ""
			}
		case '"':
			inQuotes = !inQuotes
		default:
			current += string(r)
		}
		
		// Add the last argument if we're at the end
		if i == len(argsStr)-1 && current != "" {
			args = append(args, current)
		}
	}
	
	return args
}

// Circuit breaker command handlers

func (h *Handlers) handleCircuitBreakerStatus(message *tgbotapi.Message) {
	if h.circuitBreaker == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Circuit breaker not available")
		return
	}

	status := h.circuitBreaker.GetBreakerStatus()
	healthy, issues := h.circuitBreaker.CheckHealth()

	text := "🔌 **Circuit Breaker Status**\n\n"

	// Overall health
	if healthy {
		text += "✅ **Overall Status:** Healthy\n\n"
	} else {
		text += "⚠️ **Overall Status:** Issues Detected\n\n"
	}

	// Individual circuit breaker status
	text += "📊 **Process Status:**\n"
	
	if len(status) == 0 {
		text += "• No circuit breakers active\n"
	} else {
		for processName, processStatus := range status {
			statusMap := processStatus.(map[string]interface{})
			state := statusMap["state"].(string)
			health := statusMap["health"].(string)
			totalCalls := statusMap["total_calls"]
			failureRate := statusMap["failure_rate"].(string)
			
			var emoji string
			switch health {
			case "healthy":
				emoji = "✅"
			case "degraded":
				emoji = "⚠️"
			case "recovering":
				emoji = "🔄"
			case "unhealthy":
				emoji = "❌"
			default:
				emoji = "❓"
			}
			
			text += fmt.Sprintf("• %s **%s:** %s (%s)\n", emoji, processName, state, health)
			text += fmt.Sprintf("  └ Calls: %v, Failure Rate: %s\n", totalCalls, failureRate)
		}
	}

	// Issues section
	if len(issues) > 0 {
		text += "\n🚨 **Issues:**\n"
		for _, issue := range issues {
			text += fmt.Sprintf("• %s\n", issue)
		}
	}

	text += "\n💡 Use `/cbreset` to reset circuit breakers"

	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleCircuitBreakerReset(message *tgbotapi.Message, args []string) {
	if h.circuitBreaker == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Circuit breaker not available")
		return
	}

	if len(args) == 0 {
		// Reset all circuit breakers
		h.circuitBreaker.ResetAllBreakers()
		h.bot.SendMessage(message.Chat.ID, "✅ All circuit breakers have been reset to CLOSED state")
		return
	}

	processName := args[0]
	err := h.circuitBreaker.ResetBreaker(processName)
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to reset circuit breaker: %v", err))
		return
	}

	h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("✅ Circuit breaker for `%s` has been reset to CLOSED state", processName))
}

func (h *Handlers) handleCircuitBreakerOpen(message *tgbotapi.Message, args []string) {
	if h.circuitBreaker == nil {
		h.bot.SendMessage(message.Chat.ID, "❌ Circuit breaker not available")
		return
	}

	if len(args) == 0 {
		h.bot.SendMessage(message.Chat.ID, "❌ Usage: /cbopen <process_name>\nAvailable processes: extract, convert")
		return
	}

	processName := args[0]
	err := h.circuitBreaker.ForceOpenBreaker(processName)
	if err != nil {
		h.bot.SendMessage(message.Chat.ID, fmt.Sprintf("❌ Failed to open circuit breaker: %v", err))
		return
	}

	text := fmt.Sprintf("⚠️ **Circuit Breaker Manually Opened**\n\n🔌 Process: `%s`\n📝 Status: OPEN\n🚫 All calls will be rejected\n\n💡 Use `/cbreset %s` to close it", processName, processName)
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleGracefulDegradation(message *tgbotapi.Message) {
	text := "🛡️ **Graceful Degradation System Status**\n\n"
	
	// Get extraction worker dependency report
	if h.extractionWorker != nil {
		healthy, issues := h.extractionWorker.GetDependencyHealth()
		text += "📦 **Extraction Dependencies:**\n"
		if healthy {
			text += "✅ All extraction dependencies are healthy\n"
		} else {
			text += "⚠️ Some dependencies have issues:\n"
			for _, issue := range issues {
				text += fmt.Sprintf("• %s\n", issue)
			}
		}
		text += "\n"
	}
	
	// Get conversion worker dependency report
	if h.conversionWorker != nil {
		healthy, issues := h.conversionWorker.GetDependencyHealth()
		text += "🔄 **Conversion Dependencies:**\n"
		if healthy {
			text += "✅ All conversion dependencies are healthy\n"
		} else {
			text += "⚠️ Some dependencies have issues:\n"
			for _, issue := range issues {
				text += fmt.Sprintf("• %s\n", issue)
			}
		}
		text += "\n"
	}
	
	text += "💡 Use `/dephealth` for detailed dependency status\n"
	text += "💡 Use `/queuestatus` to see queued operations"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleDependencyHealth(message *tgbotapi.Message) {
	text := "🔍 **Detailed Dependency Health Report**\n\n"
	
	reportGenerated := false
	
	// Get detailed reports from workers
	if h.extractionWorker != nil {
		// Note: This would need the degradation manager to be exposed
		// For now, we'll show basic health info
		healthy, issues := h.extractionWorker.GetDependencyHealth()
		text += "📦 **Extraction Worker Dependencies:**\n"
		
		if healthy {
			text += "✅ Status: All dependencies available\n"
			text += "🔗 Dependencies: extract.go, go runtime, extraction directory\n"
		} else {
			text += "⚠️ Status: Some dependencies unavailable\n"
			text += "❌ Issues:\n"
			for _, issue := range issues {
				text += fmt.Sprintf("  • %s\n", issue)
			}
		}
		text += "\n"
		reportGenerated = true
	}
	
	if h.conversionWorker != nil {
		healthy, issues := h.conversionWorker.GetDependencyHealth()
		text += "🔄 **Conversion Worker Dependencies:**\n"
		
		if healthy {
			text += "✅ Status: All dependencies available\n"
			text += "🔗 Dependencies: convert.go, go runtime, pass directory\n"
		} else {
			text += "⚠️ Status: Some dependencies unavailable\n"
			text += "❌ Issues:\n"
			for _, issue := range issues {
				text += fmt.Sprintf("  • %s\n", issue)
			}
		}
		text += "\n"
		reportGenerated = true
	}
	
	if !reportGenerated {
		text += "❌ No workers available for health reporting\n"
	}
	
	text += "🔄 **Fallback Strategies:**\n"
	text += "• **Queue:** Operations queued until dependency recovers\n"
	text += "• **Skip:** Operation skipped with notification\n"
	text += "• **Alternate:** Alternative processing method used\n"
	text += "• **Manual:** Manual intervention required\n"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleQueueStatus(message *tgbotapi.Message) {
	text := "📋 **Queued Operations Status**\n\n"
	
	// Note: To get actual queued operations, we'd need to expose the degradation manager
	// For now, we'll show general queue information
	
	hasQueues := false
	
	if h.extractionWorker != nil {
		text += "📦 **Extraction Queue:**\n"
		text += "• Status: Monitoring for queued operations\n"
		text += "• Fallback: Operations queued when extract.go unavailable\n\n"
		hasQueues = true
	}
	
	if h.conversionWorker != nil {
		text += "🔄 **Conversion Queue:**\n"
		text += "• Status: Monitoring for queued operations\n"
		text += "• Fallback: Operations queued when convert.go unavailable\n\n"
		hasQueues = true
	}
	
	if !hasQueues {
		text += "❌ No workers available for queue status reporting\n"
	} else {
		text += "⏱️ **Queue Configuration:**\n"
		text += "• Max wait time: 24 hours\n"
		text += "• Check interval: 30 seconds\n"
		text += "• Auto-cleanup: Expired operations removed\n\n"
		
		text += "💡 Queued operations will be processed automatically when dependencies recover"
	}
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleSecurity(message *tgbotapi.Message) {
	text := "🔒 **Security System Status**\n\n"
	
	// Get recent security events (last 24 hours)
	if h.taskStore != nil {
		db := h.taskStore.GetDB()
		securityAudit := storage.NewSecurityAuditLogger(db, h.logger)
		
		since := time.Now().Add(-24 * time.Hour)
		stats, err := securityAudit.GetSecurityStats(since)
		if err != nil {
			text += "❌ Unable to retrieve security statistics\n\n"
		} else {
			text += "📊 **Last 24 Hours:**\n"
			
			// Event counts by type
			if len(stats.EventsByType) > 0 {
				text += "📋 **Events by Type:**\n"
				for eventType, count := range stats.EventsByType {
					emoji := "📝"
					switch eventType {
					case storage.SecurityEventFileValidation:
						emoji = "🔍"
					case storage.SecurityEventFileQuarantine:
						emoji = "🚨"
					case storage.SecurityEventFileSanitization:
						emoji = "🧹"
					case storage.SecurityEventSuspiciousContent:
						emoji = "⚠️"
					}
					text += fmt.Sprintf("• %s %s: %d\n", emoji, eventType, count)
				}
				text += "\n"
			}
			
			// Threat level distribution
			if len(stats.EventsByThreatLevel) > 0 {
				text += "⚡ **Threat Levels:**\n"
				for threatLevel, count := range stats.EventsByThreatLevel {
					emoji := "✅"
					switch threatLevel {
					case utils.ThreatLevelLow:
						emoji = "🟡"
					case utils.ThreatLevelMedium:
						emoji = "🟠"
					case utils.ThreatLevelHigh:
						emoji = "🔴"
					case utils.ThreatLevelCritical:
						emoji = "💀"
					}
					text += fmt.Sprintf("• %s %s: %d\n", emoji, threatLevel.String(), count)
				}
				text += "\n"
			}
			
			// Actions taken
			if len(stats.ActionsTaken) > 0 {
				text += "🎯 **Actions Taken:**\n"
				for action, count := range stats.ActionsTaken {
					emoji := "✅"
					switch action {
					case storage.SecurityActionQuarantine:
						emoji = "🚨"
					case storage.SecurityActionSanitize:
						emoji = "🧹"
					case storage.SecurityActionReject:
						emoji = "❌"
					case storage.SecurityActionMonitor:
						emoji = "👁️"
					}
					text += fmt.Sprintf("• %s %s: %d\n", emoji, action, count)
				}
				text += "\n"
			}
		}
	}
	
	text += "💡 Use `/secstats [hours]` for detailed statistics\n"
	text += "💡 Use `/quarantine` to view quarantined files"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleSecurityStats(message *tgbotapi.Message, args []string) {
	// Default to last 24 hours
	hours := 24
	if len(args) > 0 {
		if h, err := parseIntArg(args[0]); err == nil && h > 0 && h <= 168 { // Max 1 week
			hours = h
		}
	}
	
	text := fmt.Sprintf("📊 **Security Statistics - Last %d Hours**\n\n", hours)
	
	if h.taskStore != nil {
		db := h.taskStore.GetDB()
		securityAudit := storage.NewSecurityAuditLogger(db, h.logger)
		
		since := time.Now().Add(-time.Duration(hours) * time.Hour)
		
		// Get recent events
		events, err := securityAudit.GetSecurityEvents(20, 0)
		if err != nil {
			text += "❌ Unable to retrieve security events\n"
		} else {
			if len(events) == 0 {
				text += "✅ No security events in the specified period\n"
			} else {
				text += fmt.Sprintf("🔍 **Recent Events (%d shown):**\n", len(events))
				for _, event := range events {
					if event.Timestamp.After(since) {
						emoji := "📝"
						switch event.EventType {
						case storage.SecurityEventFileQuarantine:
							emoji = "🚨"
						case storage.SecurityEventFileSanitization:
							emoji = "🧹"
						case storage.SecurityEventSuspiciousContent:
							emoji = "⚠️"
						}
						
						timeStr := event.Timestamp.Format("15:04")
						text += fmt.Sprintf("%s **%s** (%s)\n", emoji, event.EventType, timeStr)
						text += fmt.Sprintf("  └ %s - %s\n", event.FileName, event.ThreatLevel.String())
					}
				}
			}
		}
	} else {
		text += "❌ Security audit system not available\n"
	}
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleQuarantine(message *tgbotapi.Message) {
	text := "🚨 **Quarantine System Status**\n\n"
	
	// Check quarantine directory
	quarantineDir := "app/extraction/files/errors"
	files, err := filepath.Glob(filepath.Join(quarantineDir, "quarantine_*"))
	if err != nil {
		text += "❌ Unable to access quarantine directory\n"
	} else {
		if len(files) == 0 {
			text += "✅ No files currently in quarantine\n"
		} else {
			text += fmt.Sprintf("📂 **Files in Quarantine (%d):**\n", len(files))
			
			// Show most recent 10 files
			recentCount := len(files)
			if recentCount > 10 {
				recentCount = 10
			}
			
			for i := 0; i < recentCount; i++ {
				fileName := filepath.Base(files[i])
				if info, err := os.Stat(files[i]); err == nil {
					age := time.Since(info.ModTime())
					ageStr := ""
					if age < time.Hour {
						ageStr = fmt.Sprintf("%.0fm ago", age.Minutes())
					} else if age < 24*time.Hour {
						ageStr = fmt.Sprintf("%.0fh ago", age.Hours())
					} else {
						ageStr = fmt.Sprintf("%.0fd ago", age.Hours()/24)
					}
					text += fmt.Sprintf("• `%s` (%s)\n", fileName, ageStr)
				}
			}
			
			if len(files) > 10 {
				text += fmt.Sprintf("\n... and %d more files\n", len(files)-10)
			}
		}
	}
	
	text += "\n💡 Files are quarantined when they pose security risks\n"
	text += "💡 Review quarantined files manually in `app/extraction/files/errors/`"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

// parseIntArg parses integer argument with error handling
func parseIntArg(arg string) (int, error) {
	var result int
	if _, err := fmt.Sscanf(arg, "%d", &result); err != nil {
		return 0, err
	}
	return result, nil
}

func (h *Handlers) handleSignatures(message *tgbotapi.Message) {
	text := "🔐 **Enhanced File Signature Validation**\n\n"
	
	// Get signature validation information from download worker
	if h.downloadWorker != nil {
		// Create a temporary security validator to get info
		tempValidator := utils.NewSecurityValidator(h.logger, h.config)
		validationSummary := tempValidator.GetValidationSummary()
		
		text += "✅ **Security Features Active:**\n"
		if features, ok := validationSummary["security_features"].([]string); ok {
			for _, feature := range features {
				text += fmt.Sprintf("• %s\n", feature)
			}
		}
		text += "\n"
		
		// Enhanced signature info
		if enhancedInfo, ok := validationSummary["enhanced_signatures"].(map[string]interface{}); ok {
			text += "🔍 **Signature Database:**\n"
			
			if malwareCount, ok := enhancedInfo["malware_signatures_count"].(int); ok {
				text += fmt.Sprintf("• Malware signatures: %d patterns\n", malwareCount)
			}
			
			if polyglotCount, ok := enhancedInfo["polyglot_patterns_count"].(int); ok {
				text += fmt.Sprintf("• Polyglot detection: %d patterns\n", polyglotCount)
			}
			
			if suspiciousCount, ok := enhancedInfo["suspicious_patterns_count"].(int); ok {
				text += fmt.Sprintf("• Suspicious patterns: %d patterns\n", suspiciousCount)
			}
			
			text += "\n"
			
			// Supported file types with signatures
			if allowedSigs, ok := enhancedInfo["allowed_signatures"].(map[string]interface{}); ok {
				text += "📁 **Supported File Types:**\n"
				for fileType, rules := range allowedSigs {
					if ruleList, ok := rules.([]map[string]interface{}); ok {
						text += fmt.Sprintf("• **%s**: %d signature rules\n", strings.ToUpper(fileType), len(ruleList))
						
						// Show first few signature details
						shown := 0
						for _, rule := range ruleList {
							if shown >= 2 { // Limit to avoid spam
								break
							}
							if name, ok := rule["name"].(string); ok {
								if magicHex, ok := rule["magic_hex"].(string); ok && magicHex != "" {
									text += fmt.Sprintf("  └ %s (Magic: %s)\n", name, magicHex)
								} else {
									text += fmt.Sprintf("  └ %s\n", name)
								}
								shown++
							}
						}
						if len(ruleList) > 2 {
							text += fmt.Sprintf("  └ ... and %d more rules\n", len(ruleList)-2)
						}
					}
				}
			}
		}
		
		text += "\n🛡️ **Anti-Malware Protection:**\n"
		text += "• PE/ELF executable detection\n"
		text += "• Java class file detection\n"
		text += "• Script injection prevention\n"
		text += "• Polyglot file analysis\n"
		text += "• Archive bomb detection\n"
		text += "• File type spoofing prevention\n"
		
		text += "\n🔒 **Validation Process:**\n"
		text += "1. Magic byte signature verification\n"
		text += "2. File structure consistency checks\n"
		text += "3. Malware signature scanning\n"
		text += "4. Polyglot pattern detection\n"
		text += "5. Anti-spoofing validation\n"
		text += "6. Entropy analysis\n"
		text += "7. Content pattern analysis\n"
		
	} else {
		text += "❌ Signature validation system not available\n"
	}
	
	text += "\n💡 Enhanced signature validation prevents file type confusion attacks\n"
	text += "💡 All files are verified against multiple signature databases"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleTempStats(message *tgbotapi.Message) {
	text := "🗂️ **Secure Temporary File Statistics**\n\n"
	
	if h.downloadWorker != nil {
		stats := h.downloadWorker.GetTempManagerStats()
		if tempStats, ok := stats.(utils.TempFileStats); ok {
			text += "📊 **Current Session:**\n"
			text += fmt.Sprintf("• Session ID: `%s`\n", tempStats.SessionID)
			text += fmt.Sprintf("• Base Directory: `%s`\n", tempStats.BaseDirectory)
			text += fmt.Sprintf("• Active Files: %d\n", tempStats.TotalFiles)
			text += fmt.Sprintf("• Locked Files: %d\n", tempStats.LockedFiles)
			text += fmt.Sprintf("• Total Size: %s\n", formatBytes(tempStats.TotalSize))
			text += fmt.Sprintf("• Max File Age: %v\n", tempStats.MaxAge)
			text += fmt.Sprintf("• Secure Delete: %v\n", tempStats.SecureDelete)
			
			if tempStats.OldestFileAge > 0 {
				text += fmt.Sprintf("• Oldest File: %v old\n", tempStats.OldestFileAge.Round(time.Second))
			}
			
			text += "\n🔒 **Security Features:**\n"
			text += "• Secure file creation with restricted permissions\n"
			text += "• Reference counting to prevent premature cleanup\n"
			text += "• Automatic cleanup based on age and usage\n"
			text += "• Multi-pass secure deletion (DoD 5220.22-M)\n"
			text += "• Session isolation for file management\n"
			text += "• File locking to prevent accidental removal\n"
			
			text += "\n🧹 **Cleanup Methods:**\n"
			text += "• **Standard**: Regular file deletion\n"
			text += "• **Secure**: Multi-pass overwrite then delete\n"
			text += "• **Immediate**: Delete as soon as references reach zero\n"
			text += "• **Retain Logs**: Move to logs directory for audit\n"
			
			text += "\n⚙️ **Management:**\n"
			text += "• Background cleanup runs every 5 minutes\n"
			text += "• Files older than 30 minutes are cleaned up\n"
			text += "• Graceful shutdown ensures no data loss\n"
			text += "• Secure deletion uses cryptographic randomness\n"
			
		} else {
			text += "❌ Temporary file statistics not available\n"
			text += "The secure temporary file manager may not be initialized\n"
		}
	} else {
		text += "❌ Download worker not available\n"
		text += "Cannot access temporary file statistics\n"
	}
	
	text += "\n💡 Secure temporary files protect against data leakage\n"
	text += "💡 All temporary data is securely cleaned up on shutdown"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleRateLimit(message *tgbotapi.Message, args []string) {
	text := "⏰ **Rate Limiting System**\n\n"
	
	if h.auth != nil {
		rateLimiter := h.auth.GetRateLimiter()
		if rateLimiter != nil {
			stats := rateLimiter.GetStats()
			
			text += "📊 **Usage Statistics:**\n"
			text += fmt.Sprintf("• Active Users: %d\n", stats.ActiveUsers)
			
			text += "\n⚙️ **System Status:**\n"
			text += "• Rate Limiting: DISABLED (single-user mode)\n"
			text += "• File Processing: Queue-based with 3 concurrent downloads\n"
			
			// Handle subcommands
			if len(args) > 0 {
				subcommand := args[0]
				switch subcommand {
				case "users":
					text += "\n👥 **User Statistics:**\n"
					allStats := rateLimiter.GetAllStats()
					if len(allStats) == 0 {
						text += "No user activity recorded\n"
					} else {
						count := 0
						for userID, userStats := range allStats {
							if count >= 10 { // Limit to first 10 users to avoid spam
								text += fmt.Sprintf("... and %d more users\n", len(allStats)-count)
								break
							}
							
							username := userStats.Username
							if username == "" {
								username = "Unknown"
							}
							
							text += fmt.Sprintf("• **User %d** (@%s):\n", userID, username)
							text += fmt.Sprintf("  └ Commands this minute: %d\n", userStats.CommandCount)
							text += fmt.Sprintf("  └ Files this hour: %d\n", userStats.FileCount)
							text += fmt.Sprintf("  └ Last command: %s\n", userStats.LastCommandTime.Format("15:04:05"))
							text += fmt.Sprintf("  └ Last file: %s\n", userStats.LastFileTime.Format("15:04:05"))
							
							count++
						}
					}
				
				case "reset":
					if len(args) > 1 {
						// Try to parse user ID for reset
						var targetUserID int64
						if _, err := fmt.Sscanf(args[1], "%d", &targetUserID); err == nil {
							h.auth.ResetUserRateLimits(targetUserID)
							text += fmt.Sprintf("\n✅ Usage statistics reset for user %d\n", targetUserID)
						} else {
							text += fmt.Sprintf("\n❌ Invalid user ID: %s\n", args[1])
						}
					} else {
						text += "\n❌ Usage: `/ratelimit reset <user_id>`\n"
					}
				
				case "status":
					currentUserID := message.From.ID
					userStats := rateLimiter.GetUserStats(currentUserID)
					if userStats != nil {
						text += fmt.Sprintf("\n👤 **Your Usage Statistics:**\n")
						text += fmt.Sprintf("• Commands this minute: %d\n", userStats.CommandCount)
						text += fmt.Sprintf("• Files this hour: %d\n", userStats.FileCount)
						text += fmt.Sprintf("• Last command: %s\n", userStats.LastCommandTime.Format("2006-01-02 15:04:05"))
						text += fmt.Sprintf("• Last file upload: %s\n", userStats.LastFileTime.Format("2006-01-02 15:04:05"))
						text += "• Status: ✅ **No rate limiting active**\n"
					} else {
						text += "\n👤 **Your Rate Limit Status:**\n"
						text += "• No activity recorded yet\n"
					}
				
				default:
					text += fmt.Sprintf("\n❌ Unknown subcommand: %s\n", subcommand)
					text += "\n📖 **Available subcommands:**\n"
					text += "• `/ratelimit users` - Show all user statistics\n"
					text += "• `/ratelimit status` - Show your current status\n"
					text += "• `/ratelimit reset <user_id>` - Reset limits for user\n"
				}
			} else {
				text += "\n📖 **Available subcommands:**\n"
				text += "• `/ratelimit users` - Show all user statistics\n"
				text += "• `/ratelimit status` - Show your current status\n"
				text += "• `/ratelimit reset <user_id>` - Reset limits for user\n"
			}
			
			text += "\n🛡️ **Protection Features:**\n"
			text += "• Progressive blocking (1min → 5min → 15min → 1hour)\n"
			text += "• Separate limits for commands and file uploads\n"
			text += "• Burst allowance for temporary activity spikes\n"
			text += "• Automatic token refill over time\n"
			text += "• Persistent violation tracking\n"
			
		} else {
			text += "❌ Rate limiter not available\n"
		}
	} else {
		text += "❌ Authentication system not available\n"
	}
	
	text += "\n💡 Rate limiting prevents abuse and ensures fair usage\n"
	text += "💡 Limits are enforced per admin user independently"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

func (h *Handlers) handleAudit(message *tgbotapi.Message, args []string) {
	text := "📋 **Admin Audit Log System**\n\n"
	
	if h.auth == nil || h.auth.GetAuditLogger() == nil {
		text += "❌ Audit logging system not available\n"
		h.bot.SendMessage(message.Chat.ID, text)
		return
	}

	auditLogger := h.auth.GetAuditLogger()
	
	// Handle subcommands
	if len(args) > 0 {
		subcommand := args[0]
		switch subcommand {
		case "stats":
			// Show audit statistics
			hours := 24
			if len(args) > 1 {
				if h, err := fmt.Sscanf(args[1], "%d", &hours); err != nil || h <= 0 {
					hours = 24
				}
			}
			
			stats, err := auditLogger.GetAuditStats(time.Duration(hours) * time.Hour)
			if err != nil {
				text += fmt.Sprintf("❌ Failed to get audit statistics: %v\n", err)
			} else {
				text += fmt.Sprintf("📊 **Audit Statistics (Last %d hours):**\n", hours)
				text += fmt.Sprintf("• Total Entries: %d\n", stats.TotalEntries)
				text += fmt.Sprintf("• Successful Actions: %d\n", stats.SuccessfulActions)
				text += fmt.Sprintf("• Failed Actions: %d\n", stats.FailedActions)
				text += fmt.Sprintf("• Blocked Actions: %d\n", stats.BlockedActions)
				text += fmt.Sprintf("• Rate Limited: %d\n", stats.RateLimitedActions)
				text += fmt.Sprintf("• Unique Users: %d\n", stats.UniqueUsers)
				text += fmt.Sprintf("• Unique Actions: %d\n", stats.UniqueActions)
				text += fmt.Sprintf("• Avg Duration: %.1fms\n", stats.AvgDurationMs)
				
				if len(stats.ActionBreakdown) > 0 {
					text += "\n🔢 **Top Actions:**\n"
					count := 0
					for action, actionCount := range stats.ActionBreakdown {
						if count >= 5 { // Limit to top 5
							break
						}
						text += fmt.Sprintf("• %s: %d\n", action, actionCount)
						count++
					}
				}
			}
		
		case "recent":
			// Show recent audit entries
			limit := 10
			if len(args) > 1 {
				if l, err := fmt.Sscanf(args[1], "%d", &limit); err != nil || l <= 0 || l > 50 {
					limit = 10
				}
			}
			
			filters := storage.AuditFilters{
				Limit: limit,
			}
			
			entries, err := auditLogger.GetAuditEntries(filters)
			if err != nil {
				text += fmt.Sprintf("❌ Failed to get recent audit entries: %v\n", err)
			} else {
				text += fmt.Sprintf("📝 **Recent Audit Entries (Last %d):**\n", limit)
				
				if len(entries) == 0 {
					text += "No audit entries found\n"
				} else {
					for _, entry := range entries {
						username := entry.Username
						if username == "" {
							username = "Unknown"
						}
						
						resultEmoji := "✅"
						switch entry.Result {
						case "FAILED":
							resultEmoji = "❌"
						case "BLOCKED":
							resultEmoji = "🚫"
						case "RATE_LIMITED":
							resultEmoji = "⏰"
						case "SECURITY_EVENT":
							resultEmoji = "🛡️"
						}
						
						text += fmt.Sprintf("• %s **%s** @%s - %s (%s)\n", 
							resultEmoji, 
							entry.Action, 
							username, 
							entry.Resource,
							entry.Timestamp.Format("15:04:05"))
							
						if entry.ErrorMsg != "" {
							text += fmt.Sprintf("  └ Error: %s\n", entry.ErrorMsg)
						}
					}
				}
			}
		
		case "user":
			// Show audit entries for specific user
			if len(args) < 2 {
				text += "❌ Usage: `/audit user <user_id>`\n"
			} else {
				var targetUserID int64
				if _, err := fmt.Sscanf(args[1], "%d", &targetUserID); err != nil {
					text += fmt.Sprintf("❌ Invalid user ID: %s\n", args[1])
				} else {
					filters := storage.AuditFilters{
						UserID: targetUserID,
						Limit:  20,
					}
					
					entries, err := auditLogger.GetAuditEntries(filters)
					if err != nil {
						text += fmt.Sprintf("❌ Failed to get user audit entries: %v\n", err)
					} else {
						text += fmt.Sprintf("👤 **Audit Entries for User %d (Last 20):**\n", targetUserID)
						
						if len(entries) == 0 {
							text += "No audit entries found for this user\n"
						} else {
							for _, entry := range entries {
								resultEmoji := "✅"
								switch entry.Result {
								case "FAILED":
									resultEmoji = "❌"
								case "BLOCKED":
									resultEmoji = "🚫"
								case "RATE_LIMITED":
									resultEmoji = "⏰"
								}
								
								text += fmt.Sprintf("• %s **%s** - %s (%s)\n", 
									resultEmoji, 
									entry.Action, 
									entry.Resource,
									entry.Timestamp.Format("01-02 15:04"))
							}
						}
					}
				}
			}
		
		case "action":
			// Show audit entries for specific action
			if len(args) < 2 {
				text += "❌ Usage: `/audit action <action_type>`\n"
			} else {
				actionType := strings.ToUpper(args[1])
				filters := storage.AuditFilters{
					Action: actionType,
					Limit:  15,
				}
				
				entries, err := auditLogger.GetAuditEntries(filters)
				if err != nil {
					text += fmt.Sprintf("❌ Failed to get action audit entries: %v\n", err)
				} else {
					text += fmt.Sprintf("🔍 **Audit Entries for Action '%s' (Last 15):**\n", actionType)
					
					if len(entries) == 0 {
						text += "No audit entries found for this action\n"
					} else {
						for _, entry := range entries {
							username := entry.Username
							if username == "" {
								username = "Unknown"
							}
							
							resultEmoji := "✅"
							switch entry.Result {
							case "FAILED":
								resultEmoji = "❌"
							case "BLOCKED":
								resultEmoji = "🚫"
							case "RATE_LIMITED":
								resultEmoji = "⏰"
							}
							
							text += fmt.Sprintf("• %s @%s - %s (%s)\n", 
								resultEmoji, 
								username, 
								entry.Resource,
								entry.Timestamp.Format("01-02 15:04"))
						}
					}
				}
			}
		
		case "cleanup":
			// Cleanup old audit entries
			days := 30
			if len(args) > 1 {
				if d, err := fmt.Sscanf(args[1], "%d", &days); err != nil || d <= 0 || d > 365 {
					days = 30
				}
			}
			
			deleted, err := auditLogger.CleanupOldEntries(time.Duration(days) * 24 * time.Hour)
			if err != nil {
				text += fmt.Sprintf("❌ Failed to cleanup audit entries: %v\n", err)
			} else {
				text += fmt.Sprintf("🧹 **Audit Cleanup Completed:**\n")
				text += fmt.Sprintf("• Deleted %d entries older than %d days\n", deleted, days)
				
				// Log the cleanup action
				h.auth.LogSystemAction(
					message.From.ID, 
					message.From.UserName, 
					storage.AdminActionCleanup, 
					"audit_log",
					map[string]interface{}{
						"days_threshold": days,
						"entries_deleted": deleted,
					}, 
					"SUCCESS", 
					nil)
			}
		
		default:
			text += fmt.Sprintf("❌ Unknown subcommand: %s\n", subcommand)
			text += "\n📖 **Available subcommands:**\n"
			text += "• `/audit stats [hours]` - Audit statistics (default: 24h)\n"
			text += "• `/audit recent [limit]` - Recent entries (default: 10)\n"
			text += "• `/audit user <user_id>` - Entries for specific user\n"
			text += "• `/audit action <type>` - Entries for specific action\n"
			text += "• `/audit cleanup [days]` - Cleanup old entries (default: 30 days)\n"
		}
	} else {
		// Show overview
		stats, err := auditLogger.GetAuditStats(24 * time.Hour)
		if err != nil {
			text += "❌ Failed to get audit overview\n"
		} else {
			text += "📊 **24-Hour Overview:**\n"
			text += fmt.Sprintf("• Total Entries: %d\n", stats.TotalEntries)
			text += fmt.Sprintf("• Success Rate: %.1f%%\n", float64(stats.SuccessfulActions)/float64(stats.TotalEntries)*100)
			text += fmt.Sprintf("• Unique Users: %d\n", stats.UniqueUsers)
			text += fmt.Sprintf("• Blocked Actions: %d\n", stats.BlockedActions)
		}
		
		text += "\n📖 **Available subcommands:**\n"
		text += "• `/audit stats [hours]` - Detailed audit statistics\n"
		text += "• `/audit recent [limit]` - Recent audit entries\n"
		text += "• `/audit user <user_id>` - User-specific entries\n"
		text += "• `/audit action <type>` - Action-specific entries\n"
		text += "• `/audit cleanup [days]` - Cleanup old entries\n"
	}
	
	text += "\n💡 Audit logging tracks all admin actions for security\n"
	text += "💡 All commands, file operations, and security events are logged"
	
	options := &MessageOptions{ParseMode: "Markdown"}
	h.bot.SendMessageWithOptions(message.Chat.ID, text, options)
}

// formatBytes formats byte count as human-readable string
func formatBytes(bytes int64) string {
	const unit = 1024
	if bytes < unit {
		return fmt.Sprintf("%d B", bytes)
	}
	
	div, exp := int64(unit), 0
	for n := bytes / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	
	units := []string{"B", "KB", "MB", "GB", "TB", "PB", "EB"}
	return fmt.Sprintf("%.1f %s", float64(bytes)/float64(div), units[exp+1])
}

// getTaskFilenameMapping returns a map of Local Bot API filenames to original filenames
func (h *Handlers) getTaskFilenameMapping() map[string]string {
	taskMap := make(map[string]string)
	
	if h.taskStore == nil {
		return taskMap
	}
	
	// Get recent tasks that might have Local Bot API paths
	tasks, err := h.taskStore.GetTasksByStatus(models.TaskStatusDownloaded, 100)
	if err != nil {
		h.logger.WithError(err).Error("Failed to get tasks for filename mapping")
		return taskMap
	}
	
	for _, task := range tasks {
		if task.LocalAPIPath != "" {
			localFilename := filepath.Base(task.LocalAPIPath)
			taskMap[localFilename] = task.FileName
		}
	}
	
	return taskMap
}

// getOriginalFilename tries to get the original filename for a Local Bot API file
func (h *Handlers) getOriginalFilename(localAPIFilename string, taskMap map[string]string) string {
	// First check task mapping
	if originalName, exists := taskMap[localAPIFilename]; exists {
		return originalName
	}
	
	// Fallback: use the Local Bot API filename
	return localAPIFilename
}

// resolveFilenameConflict handles filename conflicts by adding a suffix
func (h *Handlers) resolveFilenameConflict(destPath, originalFilename string) string {
	finalPath := destPath
	counter := 1
	
	for {
		if _, err := os.Stat(finalPath); os.IsNotExist(err) {
			break // No conflict, use this path
		}
		
		// Check if files are the same (size and modification time)
		if h.areFilesSame(finalPath, destPath) {
			// Same file already exists, generate unique name
			ext := filepath.Ext(originalFilename)
			base := strings.TrimSuffix(originalFilename, ext)
			newFilename := fmt.Sprintf("%s_%d%s", base, counter, ext)
			finalPath = filepath.Join(filepath.Dir(destPath), newFilename)
			counter++
		} else {
			break // Different files with same name, use original path
		}
	}
	
	return finalPath
}

// areFilesSame checks if two files are the same by comparing size
func (h *Handlers) areFilesSame(path1, path2 string) bool {
	info1, err1 := os.Stat(path1)
	info2, err2 := os.Stat(path2)
	
	if err1 != nil || err2 != nil {
		return false
	}
	
	return info1.Size() == info2.Size()
}

// updateTaskLocalAPIPath updates the LocalAPIPath field for a task
func (h *Handlers) updateTaskLocalAPIPath(localAPIFilename, newPath string) {
	if h.taskStore == nil {
		return
	}
	
	// Find task by LocalAPIPath containing the filename
	tasks, err := h.taskStore.GetTasksByStatus(models.TaskStatusDownloaded, 100)
	if err != nil {
		h.logger.WithError(err).Error("Failed to get tasks for updating LocalAPIPath")
		return
	}
	
	for _, task := range tasks {
		if task.LocalAPIPath != "" && strings.Contains(task.LocalAPIPath, localAPIFilename) {
			task.LocalAPIPath = newPath
			if err := h.taskStore.UpdateTask(task); err != nil {
				h.logger.WithError(err).
					WithField("task_id", task.ID).
					Error("Failed to update task LocalAPIPath")
			}
			break
		}
	}
}

// scanExtractionFolder scans the extraction directory for extractable files (.zip, .rar)
// Returns slice of file names and error if directory access fails
func (h *Handlers) scanExtractionFolder(extractionDir string) ([]string, error) {
	// Sanitize path for security
	cleanDir := filepath.Clean(extractionDir)
	
	// Check if directory exists
	if _, err := os.Stat(cleanDir); os.IsNotExist(err) {
		return nil, fmt.Errorf("extraction directory does not exist: %s", cleanDir)
	}
	
	var extractableFiles []string
	
	// Read directory entries
	entries, err := os.ReadDir(cleanDir)
	if err != nil {
		return nil, fmt.Errorf("failed to read extraction directory: %w", err)
	}
	
	// Filter for extractable files
	for _, entry := range entries {
		if entry.IsDir() {
			continue // Skip directories
		}
		
		fileName := entry.Name()
		ext := strings.ToLower(filepath.Ext(fileName))
		
		// Check for supported archive extensions
		if ext == ".zip" || ext == ".rar" {
			extractableFiles = append(extractableFiles, fileName)
		}
	}
	
	h.logger.WithField("directory", cleanDir).
		WithField("files_found", len(extractableFiles)).
		Info("Scanned extraction folder for files")
	
	return extractableFiles, nil
}